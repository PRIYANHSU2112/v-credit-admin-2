import { Modal } from '@/components/ui/Modal'
import { KeyRound } from 'lucide-react'

export interface KeyStatusData {
  agencyName: string
  totalKeys: number
  usedKeys: number
  availableKeys: number
}

interface KeyStatusModalProps {
  isOpen: boolean
  onClose: () => void
  data: KeyStatusData | null
}

export function KeyStatusModal({ isOpen, onClose, data }: KeyStatusModalProps) {
  if (!data) return null

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2 text-[#007bff]">
          <KeyRound className="h-5 w-5" />
          <span>Key Status</span>
        </div>
      }
      size="sm"
      className="p-0 overflow-hidden"
    >
      <div className="p-6 pt-2">
        {/* Centered Agency Title */}
        <div className="text-center py-3 border-b border-gray-100">
          <h3 className="text-base font-bold text-gray-900">{data.agencyName}</h3>
        </div>

        {/* Key Metrics Table matching Screenshot 235321 */}
        <div className="divide-y divide-gray-100 text-sm">
          <div className="flex items-center justify-between py-3.5 px-2">
            <span className="font-semibold text-gray-700">Total Keys</span>
            <span className="font-bold text-gray-900 font-mono text-base">
              {data.totalKeys.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between py-3.5 px-2">
            <span className="font-semibold text-gray-700">Used Keys</span>
            <span className="font-bold text-gray-900 font-mono text-base">
              {data.usedKeys.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between py-3.5 px-2">
            <span className="font-semibold text-gray-700">Available</span>
            <span className="font-bold text-emerald-600 font-mono text-base">
              {data.availableKeys.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Close Button matching Screenshot */}
        <div className="pt-6 flex justify-center">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 rounded bg-[#5a6268] text-white text-sm font-semibold hover:bg-[#4e555b] transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </Modal>
  )
}
