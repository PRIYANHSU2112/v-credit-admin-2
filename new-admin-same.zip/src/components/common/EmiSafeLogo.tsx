interface EmiSafeLogoProps {
  className?: string
  size?: number
}

export function EmiSafeLogo({ className = '', size = 44 }: EmiSafeLogoProps) {
  return (
    <div
      style={{ width: size, height: size }}
      className={`relative shrink-0 rounded-full flex items-center justify-center bg-gradient-to-br from-lime-400 via-emerald-600 to-green-800 p-1 shadow-md border-2 border-green-400/80 ${className}`}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Outer Circle Ring */}
        <circle cx="50" cy="50" r="46" fill="#1b4d24" stroke="#4ade80" strokeWidth="3" />

        {/* Smartphone body */}
        <rect
          x="35"
          y="18"
          width="30"
          height="54"
          rx="6"
          fill="#86efac"
          stroke="#166534"
          strokeWidth="2.5"
        />
        <rect x="38" y="24" width="24" height="42" rx="3" fill="#ffffff" />

        {/* Golden Lock inside phone */}
        <path
          d="M44 42V36C44 32.6863 46.6863 30 50 30C53.3137 30 56 32.6863 56 36V42"
          stroke="#eab308"
          strokeWidth="3.5"
          strokeLinecap="round"
        />
        <rect x="42" y="42" width="16" height="14" rx="3" fill="#eab308" />
        <circle cx="50" cy="48" r="2" fill="#713f12" />
        <rect x="49" y="48" width="2" height="4" fill="#713f12" />

        {/* Supporting Hands Graphic */}
        <path
          d="M24 64C28 58 36 60 42 66L38 72C32 68 26 70 24 64Z"
          fill="#111827"
        />
        <path
          d="M76 64C72 58 64 60 58 66L62 72C68 68 74 70 76 64Z"
          fill="#111827"
        />

        {/* "EMI SAFE" Banner */}
        <rect x="24" y="73" width="52" height="13" rx="4" fill="#ffffff" />
        <text
          x="50"
          y="83"
          textAnchor="middle"
          fontSize="8.5"
          fontWeight="900"
          fill="#15803d"
          fontFamily="system-ui, sans-serif"
          letterSpacing="0.5"
        >
          EMI SAFE
        </text>

        {/* Small Checkmark */}
        <circle cx="50" cy="91" r="3.5" fill="#22c55e" />
        <path
          d="M48 91L49.5 92.5L52 89.5"
          stroke="#ffffff"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  )
}
