import { useState } from 'react'
import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import {
  ChevronRight,
  LogOut,
  X,
  LayoutDashboard,
  UserPlus,
  Users,
  FileBarChart,
  Settings,
  FileDown,
  Menu,
} from 'lucide-react'
import { useAppSelector, useAppDispatch } from '@/app/store/hooks'
import { logout } from '@/features/auth/slices/authSlice'
import { ROUTE_PATHS } from '@/app/routes/routePaths'
import { cn } from '@/lib/utils'
import { EmiSafeLogo } from '@/components/common/EmiSafeLogo'

interface AppSidebarProps {
  isCollapsed?: boolean
  setIsCollapsed?: (collapsed: boolean) => void
  isMobileOpen: boolean
  setIsMobileOpen: (open: boolean) => void
  onOpenAgreement?: () => void
}

type AccordionKey = 'userList' | 'reports' | 'systemSetting' | null

export function AppSidebar({
  isCollapsed = false,
  setIsCollapsed,
  isMobileOpen,
  setIsMobileOpen,
  onOpenAgreement,
}: AppSidebarProps) {
  const dispatch = useAppDispatch()
  const navigate = useNavigate()
  const location = useLocation()
  const { user } = useAppSelector((state) => state.auth)

  // Auto-expand accordion based on active route
  const getInitialAccordion = (): AccordionKey => {
    const p = location.pathname
    if (
      p.includes('/distributors') ||
      p.includes('/dealers') ||
      p.includes('/users') ||
      p.includes('/pending-users') ||
      p.includes('/user-search')
    ) {
      return 'userList'
    }
    if (p.includes('/reports')) {
      return 'reports'
    }
    if (p.includes('/settings')) {
      return 'systemSetting'
    }
    return 'userList'
  }

  const [openAccordion, setOpenAccordion] = useState<AccordionKey>(getInitialAccordion)

  const toggleAccordion = (key: AccordionKey) => {
    setOpenAccordion((prev) => (prev === key ? null : key))
  }

  const handleLogout = () => {
    dispatch(logout())
    navigate(ROUTE_PATHS.LOGIN)
  }

  const closeMobile = () => setIsMobileOpen(false)

  const isSuper = user?.role === 'super_admin'
  const isStockist = user?.role === 'stockist' || isSuper
  const isDistributor = user?.role === 'distributor' || isStockist

  // Pill NavLink shared style
  const pillCls = (isActive: boolean) =>
    cn(
      'flex items-center gap-2.5 w-full px-4 py-2.5 rounded-full text-xs font-bold transition-all duration-150 select-none shadow-xs',
      isActive
        ? 'btn-pill-cyan active'
        : 'btn-pill-cyan'
    )

  // Yellow sub-item style
  const yellowCls = (isActive: boolean) =>
    cn(
      'flex items-center w-full px-4 py-2 rounded-full text-xs font-semibold transition-all duration-150 select-none',
      isActive
        ? 'btn-pill-yellow active text-gray-900 shadow-xs'
        : 'btn-pill-yellow text-gray-800'
    )

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs lg:hidden"
          onClick={closeMobile}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 bottom-0 left-0 z-40 flex flex-col transition-all duration-300 ease-in-out lg:static shadow-xl',
          'bg-white border-r border-gray-200',
          isCollapsed ? 'w-20' : 'w-64',
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo Header matching Screenshot */}
        <div className="flex items-center justify-between px-4 h-16 border-b border-gray-100 shrink-0">
          <NavLink
            to={ROUTE_PATHS.OVERVIEW}
            onClick={closeMobile}
            className="flex items-center gap-2.5 overflow-hidden"
          >
            <EmiSafeLogo className="h-9 w-9 shrink-0" />
            {!isCollapsed && (
              <span className="text-sm font-black tracking-tight text-gray-900 uppercase">
                {user?.role === 'super_admin' ? 'STOCKIEST' :
                 user?.role === 'stockist' ? 'STOCKIEST' :
                 user?.role === 'distributor' ? 'DISTRIBUTOR' :
                 user?.role === 'dealer' ? 'DEALER' : 'V-CREDIT'}
              </span>
            )}
          </NavLink>

          {/* Blue 3-Line Menu Icon */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setIsCollapsed && setIsCollapsed(!isCollapsed)}
              className="hidden lg:flex p-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
              title="Toggle sidebar"
            >
              <Menu className="h-4 w-4" />
            </button>

            <button
              className="lg:hidden p-1.5 rounded-lg text-gray-500 hover:bg-gray-100"
              onClick={closeMobile}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-2.5">
          {/* DASHBOARD */}
          <NavLink
            to={ROUTE_PATHS.OVERVIEW}
            onClick={closeMobile}
            className={({ isActive }) => pillCls(isActive)}
          >
            <LayoutDashboard className="h-4 w-4 shrink-0 text-gray-800" />
            {!isCollapsed && <span className="uppercase tracking-wider">DASHBOARD</span>}
          </NavLink>

          {/* ADD NEW DISTRIBUTOR */}
          {isStockist && (
            <NavLink
              to={ROUTE_PATHS.ADD_DISTRIBUTOR}
              onClick={closeMobile}
              className={({ isActive }) => pillCls(isActive)}
            >
              <UserPlus className="h-4 w-4 shrink-0 text-gray-800" />
              {!isCollapsed && <span>Add New Distributor</span>}
            </NavLink>
          )}

          {/* USER LIST - Accordion */}
          {isDistributor && !isCollapsed && (
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => toggleAccordion('userList')}
                className={cn(
                  'flex items-center justify-between w-full px-4 py-2.5 rounded-full text-xs font-bold transition-all shadow-xs',
                  'btn-pill-cyan',
                  openAccordion === 'userList' && 'active'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <Users className="h-4 w-4 shrink-0 text-gray-800" />
                  <span>User List</span>
                </div>
                <ChevronRight
                  className={cn(
                    'h-4 w-4 transition-transform duration-200',
                    openAccordion === 'userList' ? 'rotate-90' : ''
                  )}
                />
              </button>

              {openAccordion === 'userList' && (
                <div className="ml-3 space-y-1 pt-1 animate-in fade-in slide-in-from-top-1 duration-150">
                  <NavLink to={ROUTE_PATHS.DISTRIBUTORS} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    EmiSafe Distributors
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.DEALERS} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    EmiSafe Dealers
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.USERS} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    EmiSafe Users
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.PENDING_USERS} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    EmiSafe Pending Users
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.USER_SEARCH} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    Search Users
                  </NavLink>
                </div>
              )}
            </div>
          )}

          {/* REPORTS - Accordion */}
          {!isCollapsed && (
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => toggleAccordion('reports')}
                className={cn(
                  'flex items-center justify-between w-full px-4 py-2.5 rounded-full text-xs font-bold transition-all shadow-xs',
                  'btn-pill-cyan',
                  openAccordion === 'reports' && 'active'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <FileBarChart className="h-4 w-4 shrink-0 text-gray-800" />
                  <span>Reports</span>
                </div>
                <ChevronRight
                  className={cn(
                    'h-4 w-4 transition-transform duration-200',
                    openAccordion === 'reports' ? 'rotate-90' : ''
                  )}
                />
              </button>

              {openAccordion === 'reports' && (
                <div className="ml-3 space-y-1 pt-1 animate-in fade-in slide-in-from-top-1 duration-150">
                  <NavLink to={ROUTE_PATHS.REPORT_DISTRIBUTOR_LOW_KEY} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    Distributor Low-Key Report
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.REPORT_DEALER_LOW_KEY} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    Dealer Low-Key Report
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.REPORT_TRANSFER} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    EmiSafe Transfer Report
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.REPORT_RECEIVED_KEY} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    EmiSafe Received Key Report
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.REPORT_IPHONE_TRANSFER} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    iPhone Key Transfer Report
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.REPORT_IPHONE_RECEIVED} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    iPhone Key Received
                  </NavLink>
                </div>
              )}
            </div>
          )}

          {/* SYSTEM SETTING - Accordion */}
          {isSuper && !isCollapsed && (
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => toggleAccordion('systemSetting')}
                className={cn(
                  'flex items-center justify-between w-full px-4 py-2.5 rounded-full text-xs font-bold transition-all shadow-xs',
                  'btn-pill-cyan',
                  openAccordion === 'systemSetting' && 'active'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <Settings className="h-4 w-4 shrink-0 text-gray-800" />
                  <span>System Setting</span>
                </div>
                <ChevronRight
                  className={cn(
                    'h-4 w-4 transition-transform duration-200',
                    openAccordion === 'systemSetting' ? 'rotate-90' : ''
                  )}
                />
              </button>

              {openAccordion === 'systemSetting' && (
                <div className="ml-3 space-y-1 pt-1 animate-in fade-in slide-in-from-top-1 duration-150">
                  <NavLink to={ROUTE_PATHS.SETTING_KEY_PRICE} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    Key Price Setting
                  </NavLink>
                  <NavLink to={ROUTE_PATHS.SETTING_IPHONE_KEY_PRICE} onClick={closeMobile} className={({ isActive }) => yellowCls(isActive)}>
                    iPhone Key Price Setting
                  </NavLink>
                </div>
              )}
            </div>
          )}

          {/* DOWNLOAD AGREEMENT */}
          <div className="flex items-center gap-1">
            <NavLink
              to={ROUTE_PATHS.DOWNLOAD_AGREEMENT}
              onClick={closeMobile}
              className={({ isActive }) => cn(pillCls(isActive), onOpenAgreement && !isCollapsed && 'flex-1')}
            >
              <FileDown className="h-4 w-4 shrink-0 text-gray-800" />
              {!isCollapsed && <span>Download Agreement</span>}
            </NavLink>
            {onOpenAgreement && !isCollapsed && (
              <button
                type="button"
                onClick={onOpenAgreement}
                title="Quick View Agreement Modal"
                className="px-2.5 py-1.5 rounded-full text-[11px] font-bold bg-cyan-100 text-cyan-800 hover:bg-cyan-200 transition-colors shrink-0"
              >
                View
              </button>
            )}
          </div>
        </nav>

        {/* User Footer */}
        <div className="border-t border-gray-100 p-3 shrink-0">
          <div className={cn('flex items-center gap-3 rounded-xl p-2 bg-gray-50', isCollapsed && 'justify-center p-1.5')}>
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-cyan-100 text-cyan-700 font-black text-xs uppercase">
              {user?.name ? user.name.slice(0, 2) : 'VC'}
            </div>

            {!isCollapsed && (
              <div className="flex-1 overflow-hidden">
                <p className="truncate text-xs font-black text-gray-900">{user?.name || 'V-Credit User'}</p>
                <p className="truncate text-[11px] capitalize text-gray-500">
                  {user?.role ? user.role.replace('_', ' ') : 'Administrator'}
                </p>
              </div>
            )}

            {!isCollapsed && (
              <button
                type="button"
                onClick={handleLogout}
                className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-600 transition-colors"
                title="Sign out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </aside>
    </>
  )
}
