import { useState } from 'react'
import {
  Maximize,
  Minimize,
  User,
  LogOut,
  Shield,
  Check,
  Menu,
} from 'lucide-react'
import { useAppSelector, useAppDispatch } from '@/app/store/hooks'
import { switchRoleDemo, logout } from '@/features/auth/slices/authSlice'
import type { UserRole } from '@/types/user'
import { toast } from 'sonner'

interface AppHeaderProps {
  title?: string
  subtitle?: string
  onOpenMobileSidebar: () => void
}

export function AppHeader({
  title = 'Dashboard',
  subtitle = 'HOMES',
  onOpenMobileSidebar,
}: AppHeaderProps) {
  const dispatch = useAppDispatch()
  const { user } = useAppSelector((state) => state.auth)

  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false)
  const [isProfileOpen, setIsProfileOpen] = useState(false)

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true))
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => setIsFullscreen(false))
      }
    }
  }

  const handleRoleChange = (role: UserRole) => {
    dispatch(switchRoleDemo(role))
    setIsRoleDropdownOpen(false)
    toast.success(`Active Persona switched to ${role.replace('_', ' ').toUpperCase()}`, {
      description: 'Permissions and views adapted to this tier.',
    })
  }

  const handleLogout = () => {
    dispatch(logout())
    toast.info('Signed out of V-Credit Console')
  }

  return (
    <header className="flex h-16 w-full items-center justify-between px-6 bg-white border-b border-gray-100 shadow-xs z-30">
      {/* Left: Mobile hamburger & Page Title matching Screenshots */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 rounded-lg text-gray-600 hover:bg-gray-100"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex flex-col">
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 leading-tight">
            {title}
          </h1>
          <span className="text-[11px] font-bold tracking-wider text-blue-500 uppercase">
            {subtitle}
          </span>
        </div>
      </div>

      {/* Right Icons matching Figma Screenshots in temp2 */}
      <div className="flex items-center gap-4 sm:gap-6">
        {/* Exact Green Text: No Keys for Return */}
        <span className="text-sm font-semibold text-emerald-600 hidden md:inline-block">
          No Keys for Return
        </span>

        {/* Quick Role Switcher Pill */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
            className="flex items-center gap-1.5 rounded-full bg-cyan-50 border border-cyan-300 px-3 py-1 text-xs font-bold text-cyan-800 hover:bg-cyan-100 transition-colors shadow-xs"
          >
            <Shield className="h-3.5 w-3.5 text-cyan-600" />
            <span className="capitalize">{user?.role?.replace('_', ' ') || 'Stockist'}</span>
            <span className="text-[10px] text-cyan-600">(Change)</span>
          </button>

          {isRoleDropdownOpen && (
            <div
              className="absolute right-0 mt-2 w-52 rounded-2xl border border-gray-200 bg-white p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95"
              onMouseLeave={() => setIsRoleDropdownOpen(false)}
            >
              <div className="px-2 py-1.5 text-[11px] font-bold uppercase tracking-wider text-gray-400">
                Switch Hierarchy Persona
              </div>
              {[
                { role: 'super_admin', label: 'Super Admin (Full Oversight)' },
                { role: 'stockist', label: 'Stockist (Regional Territory)' },
                { role: 'distributor', label: 'Distributor (City / Hub)' },
                { role: 'dealer', label: 'Dealer (Retail Store)' },
              ].map((item) => (
                <button
                  key={item.role}
                  type="button"
                  onClick={() => handleRoleChange(item.role as UserRole)}
                  className="flex w-full items-center justify-between rounded-xl px-2.5 py-1.5 text-xs text-gray-700 hover:bg-gray-100 transition-colors text-left"
                >
                  <span>{item.label}</span>
                  {user?.role === item.role && (
                    <Check className="h-3.5 w-3.5 text-blue-600" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Fullscreen Icon matching Screenshots */}
        <button
          type="button"
          onClick={toggleFullscreen}
          className="text-blue-500 hover:text-blue-600 p-1.5 rounded-lg hover:bg-blue-50 transition-colors"
          title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
        >
          {isFullscreen ? (
            <Minimize className="h-5 w-5" />
          ) : (
            <Maximize className="h-5 w-5" />
          )}
        </button>

        {/* Multi-Screen / Grid Icon matching Screenshots */}
        <button
          type="button"
          onClick={() => toast.info('Multi-terminal oversight monitor active')}
          className="text-gray-700 hover:text-gray-900 p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          title="Consoles Grid"
        >
          <svg
            className="h-5 w-5 stroke-current"
            viewBox="0 0 24 24"
            fill="none"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect x="2" y="3" width="20" height="14" rx="2" />
            <line x1="8" y1="21" x2="16" y2="21" />
            <line x1="12" y1="17" x2="12" y2="21" />
            <circle cx="7" cy="8" r="1.5" />
            <circle cx="17" cy="8" r="1.5" />
            <circle cx="7" cy="13" r="1.5" />
            <circle cx="17" cy="13" r="1.5" />
          </svg>
        </button>

        {/* Circular Profile Avatar (Exact black circle with silhouette) */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-900 text-white hover:opacity-90 shadow-sm transition-transform active:scale-95"
          >
            <User className="h-5 w-5 text-gray-200" />
          </button>

          {isProfileOpen && (
            <div
              className="absolute right-0 mt-2 w-56 rounded-2xl border border-gray-100 bg-white p-2.5 shadow-2xl z-50 animate-in fade-in zoom-in-95"
              onMouseLeave={() => setIsProfileOpen(false)}
            >
              <div className="px-3 py-2 border-b border-gray-100">
                <p className="text-xs font-bold text-gray-900">
                  {user?.name || 'Stockist Admin'}
                </p>
                <p className="text-[11px] text-gray-500">
                  {user?.email || 'admin@vcredit.in'}
                </p>
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-blue-100 text-blue-800">
                  {user?.role?.replace('_', ' ') || 'Stockist'}
                </span>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex w-full items-center gap-2 rounded-xl px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 font-bold"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
