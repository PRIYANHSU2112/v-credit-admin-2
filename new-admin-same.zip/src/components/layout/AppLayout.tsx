import { useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { AppSidebar } from './AppSidebar'
import { AppHeader } from './AppHeader'
import { TopProgressBar } from '@/components/common/TopProgressBar'
import { AddDistributorModal } from '@/components/common/AddDistributorModal'
import { AgreementModal } from '@/components/common/AgreementModal'

export function AppLayout() {
  const location = useLocation()
  const [isMobileOpen, setIsMobileOpen] = useState(false)
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isAddDistributorOpen, setIsAddDistributorOpen] = useState(false)
  const [isAgreementOpen, setIsAgreementOpen] = useState(false)

  // Dashboard page has emerald green wave background
  const isDashboard =
    location.pathname.endsWith('/overview') ||
    location.pathname.endsWith('/dashboard') ||
    location.pathname === '/app'

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-white text-gray-900 font-sans antialiased">
      {/* Route Navigation Progress Bar */}
      <TopProgressBar />

      {/* Sidebar Navigation */}
      <AppSidebar
        isCollapsed={isCollapsed}
        setIsCollapsed={setIsCollapsed}
        isMobileOpen={isMobileOpen}
        setIsMobileOpen={setIsMobileOpen}
        onOpenAgreement={() => setIsAgreementOpen(true)}
      />

      {/* Main Content Workspace */}
      <div className="flex flex-1 flex-col overflow-hidden min-w-0">
        {/* Top Header */}
        <AppHeader
          title="Dashboard"
          subtitle="HOMES"
          onOpenMobileSidebar={() => setIsMobileOpen(true)}
        />

        {/* Dynamic Route Content */}
        <main
          className={`flex-1 overflow-y-auto ${
            isDashboard ? 'bg-emerald-waves p-6 lg:p-8' : 'bg-[#f4f7f6] p-6 lg:p-8'
          }`}
        >
          <div className="mx-auto max-w-7xl">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Global Modals */}
      <AddDistributorModal
        isOpen={isAddDistributorOpen}
        onClose={() => setIsAddDistributorOpen(false)}
      />

      <AgreementModal
        isOpen={isAgreementOpen}
        onClose={() => setIsAgreementOpen(false)}
      />
    </div>
  )
}
