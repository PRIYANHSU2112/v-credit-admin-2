import React, { createContext, useContext, useEffect, useState } from 'react'
import { APP_CONFIG } from '@/config/app.config'
import { storage } from '@/lib/storage'

type Theme = 'dark' | 'light' | 'system'

interface ThemeProviderProps {
  children: React.ReactNode
  defaultTheme?: Theme
}

interface ThemeProviderState {
  theme: Theme
  setTheme: (theme: Theme) => void
  isDark: boolean
}

const initialState: ThemeProviderState = {
  theme: 'dark',
  setTheme: () => null,
  isDark: true,
}

const ThemeProviderContext = createContext<ThemeProviderState>(initialState)

export function ThemeProvider({
  children,
  defaultTheme = 'dark',
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(
    () => storage.get<Theme>(APP_CONFIG.storageKeys.theme, defaultTheme)
  )

  const [isDark, setIsDark] = useState<boolean>(true)

  useEffect(() => {
    const root = window.document.documentElement
    root.classList.remove('light', 'dark')

    let activeTheme = theme
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light'
      activeTheme = systemTheme
    }

    root.classList.add(activeTheme)
    setIsDark(activeTheme === 'dark')
    storage.set(APP_CONFIG.storageKeys.theme, theme)
  }, [theme])

  const value = {
    theme,
    setTheme: (newTheme: Theme) => {
      setTheme(newTheme)
    },
    isDark,
  }

  return (
    <ThemeProviderContext.Provider value={value}>
      {children}
    </ThemeProviderContext.Provider>
  )
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext)
  if (context === undefined)
    throw new Error('useTheme must be used within a ThemeProvider')
  return context
}
