import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { MOCK_DISTRIBUTORS } from '@/mocks/mockSeedData'
import { ROUTE_PATHS } from '@/app/routes/routePaths'
import { toast } from 'sonner'

export default function KeysReturnPage() {
  const navigate = useNavigate()
  const [selectedDistributor, setSelectedDistributor] = useState('Music Beats')
  const [numberOfKeys, setNumberOfKeys] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const count = parseInt(numberOfKeys, 10)
    if (isNaN(count) || count <= 0) {
      toast.error('Please enter a valid number of keys to return.')
      return
    }

    setIsSubmitting(true)
    setTimeout(() => {
      setIsSubmitting(false)
      toast.success(`Successfully processed return of ${count} keys from ${selectedDistributor}!`)
      setNumberOfKeys('')
      navigate(ROUTE_PATHS.DISTRIBUTORS)
    }, 600)
  }

  return (
    <div className="space-y-6">
      {/* Top back button */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => navigate(ROUTE_PATHS.DISTRIBUTORS)}
          className="p-1.5 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <span className="text-xs text-gray-500">Back to Distributors</span>
      </div>

      {/* Card matching Screenshot 235354 */}
      <div className="max-w-xl bg-white rounded-2xl shadow-xs border border-gray-100 p-8">
        <h2 className="text-xl font-bold text-gray-800 mb-6">keys Return</h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-700">Distributor Name</label>
            <select
              value={selectedDistributor}
              onChange={(e) => setSelectedDistributor(e.target.value)}
              className="w-full h-11 rounded border border-gray-200 bg-white px-3.5 text-xs text-gray-800 font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              {MOCK_DISTRIBUTORS.map((d) => (
                <option key={d.id} value={d.agency}>
                  {d.agency} ({d.availableKeys} available)
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-700">Number of Keys</label>
            <input
              type="number"
              min={1}
              value={numberOfKeys}
              onChange={(e) => setNumberOfKeys(e.target.value)}
              placeholder="Enter Number of Keys for Return"
              required
              className="w-full h-11 rounded border border-gray-300 px-3.5 text-xs text-gray-800 placeholder:text-gray-400 focus:outline-none focus:border-blue-500 bg-white"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-action-primary text-xs font-bold h-10 px-6 disabled:opacity-50"
            >
              {isSubmitting ? 'Processing...' : 'Return'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
