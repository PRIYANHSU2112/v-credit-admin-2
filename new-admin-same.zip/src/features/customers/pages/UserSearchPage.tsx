import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { Eye, Lock, Unlock, Settings } from 'lucide-react'
import { MOCK_USERS, type EmiSafeUserRecord } from '@/mocks/mockSeedData'
import { UserDetailsModal } from '@/components/modals/UserDetailsModal'
import { toast } from 'sonner'

export default function UserSearchPage() {
  const navigate = useNavigate()
  const [users, setUsers] = useState<EmiSafeUserRecord[]>(MOCK_USERS)
  const [searchBy, setSearchBy] = useState<'Phone' | 'Name' | 'LoanId' | 'Dealer'>('Phone')
  const [searchValue, setSearchValue] = useState('')
  const [pageSize, setPageSize] = useState(10)

  // Details Modal
  const [selectedUser, setSelectedUser] = useState<EmiSafeUserRecord | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)

  const filteredUsers = useMemo(() => {
    if (!searchValue.trim()) return users

    return users.filter((u) => {
      const q = searchValue.toLowerCase()
      if (searchBy === 'Phone') return u.userPhone.includes(q)
      if (searchBy === 'Name') return u.userName.toLowerCase().includes(q)
      if (searchBy === 'LoanId') return u.loanId?.toLowerCase().includes(q)
      if (searchBy === 'Dealer') return u.dealer.toLowerCase().includes(q)
      return true
    })
  }, [users, searchBy, searchValue])

  const handleToggleLock = (user: EmiSafeUserRecord, newLock: 'locked' | 'unlocked') => {
    setUsers(users.map((u) => (u.id === user.id ? { ...u, lockStatus: newLock } : u)))

    if (newLock === 'locked') {
      toast.error(`Remote Lock broadcast to ${user.userName}'s device`)
    } else {
      toast.success(`Device unlocked for ${user.userName}`)
    }
  }

  const handleOpenDetails = (u: EmiSafeUserRecord) => {
    setSelectedUser(u)
    setIsDetailsOpen(true)
  }

  const handleOpenDeviceControl = (u: EmiSafeUserRecord) => {
    navigate(`/app/users/${u.id}/device-control`)
  }

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title */}
      <div className="pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">User Search</h2>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 pt-2 max-w-2xl">
        <div className="space-y-1 w-44">
          <label className="text-xs font-semibold text-[#007bff]">Search By :</label>
          <select
            value={searchBy}
            onChange={(e) => setSearchBy(e.target.value as any)}
            className="w-full h-9 rounded border border-gray-300 px-3 text-xs text-gray-800 bg-white focus:outline-none focus:border-blue-500"
          >
            <option value="Phone">Phone</option>
            <option value="Name">Name</option>
            <option value="LoanId">Loan Id</option>
            <option value="Dealer">Dealer</option>
          </select>
        </div>

        <div className="space-y-1 flex-1">
          <label className="text-xs font-semibold text-[#007bff]">Search User :</label>
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Enter phone, borrower name or loan id..."
              className="flex-1 h-9 rounded border border-gray-300 px-3 text-xs text-gray-800 focus:outline-none focus:border-blue-500"
            />
            <button
              type="button"
              onClick={() => toast.success(`Found ${filteredUsers.length} records matching "${searchValue}"`)}
              className="btn-action-primary text-xs font-bold h-9 px-6"
            >
              search
            </button>
          </div>
        </div>
      </div>

      {/* Table Controls */}
      <div className="flex items-center justify-between gap-3 pt-3 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span>entries</span>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left enterprise-table">
          <thead>
            <tr>
              <th className="w-12">#</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Loan Id</th>
              <th>Activation Date</th>
              <th>Dealer</th>
              <th>Dealer Phone</th>
              <th className="text-center">Lock/Unlock</th>
              <th className="text-center">User Feature</th>
              <th className="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.length === 0 ? (
              <tr>
                <td colSpan={10} className="text-center py-8 text-gray-400">
                  No data available in table
                </td>
              </tr>
            ) : (
              filteredUsers.map((u, index) => (
                <tr key={u.id}>
                  <td>{index + 1}</td>
                  <td className="font-bold text-gray-900">{u.userName}</td>
                  <td>{u.userPhone}</td>
                  <td className="font-mono text-xs text-blue-600 font-semibold">{u.loanId || '—'}</td>
                  <td className="text-xs text-gray-600">{u.activationDate}</td>
                  <td className="text-xs font-semibold text-gray-800">{u.dealer}</td>
                  <td>{u.dealerPhone}</td>
                  <td className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleToggleLock(u, 'locked')}
                        className={`p-1.5 rounded transition-colors shadow-2xs ${
                          u.lockStatus === 'locked'
                            ? 'bg-red-700 text-white'
                            : 'bg-[#dc3545] text-white hover:bg-[#c82333]'
                        }`}
                        title="Lock Phone"
                      >
                        <Lock className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleLock(u, 'unlocked')}
                        className={`p-1.5 rounded transition-colors shadow-2xs ${
                          u.lockStatus === 'unlocked'
                            ? 'bg-green-700 text-white'
                            : 'bg-[#28a745] text-white hover:bg-[#218838]'
                        }`}
                        title="Unlock Phone"
                      >
                        <Unlock className="h-3 w-3" />
                      </button>
                    </div>
                  </td>
                  <td className="text-center">
                    <button
                      type="button"
                      onClick={() => handleOpenDeviceControl(u)}
                      className="p-1.5 rounded-full bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors inline-flex items-center justify-center"
                      title="Open EMI SAFE Device Control"
                    >
                      <Settings className="h-3.5 w-3.5" />
                    </button>
                  </td>
                  <td className="text-center">
                    <button
                      type="button"
                      onClick={() => handleOpenDetails(u)}
                      className="p-1.5 rounded-full bg-cyan-100 text-cyan-700 hover:bg-cyan-200 transition-colors inline-flex items-center justify-center"
                      title="Inspect User Details"
                    >
                      <Eye className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>Showing 1 to {filteredUsers.length} of {filteredUsers.length} entries</span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Next
          </button>
        </div>
      </div>

      {/* Details Modal */}
      <UserDetailsModal
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        user={selectedUser}
      />
    </div>
  )
}
