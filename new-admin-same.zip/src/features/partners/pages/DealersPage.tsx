import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { Eye, LogIn, FileText, Edit, Key } from 'lucide-react'
import { MOCK_DEALERS, type DealerRecord } from '@/mocks/mockSeedData'
import { DealerDetailsModal } from '@/components/modals/DealerDetailsModal'
import { DealerFollowupModal } from '@/components/modals/DealerFollowupModal'
import { KeysReturnModal } from '@/components/modals/KeysReturnModal'
import { toast } from 'sonner'

export default function DealersPage() {
  const navigate = useNavigate()
  const [dealers] = useState<DealerRecord[]>(MOCK_DEALERS)

  // Radio button search filter mode: 'distributor' | 'dealer_info' | 'city_state'
  const [searchMode, setSearchMode] = useState<'distributor' | 'dealer_info' | 'city_state'>('distributor')
  const [selectedDistributor, setSelectedDistributor] = useState('VEDA ENTERPRISE')
  const [dealerQuery, setDealerQuery] = useState('')
  const [cityStateQuery, setCityStateQuery] = useState('')
  const [tableSearch, setTableSearch] = useState('')
  const [pageSize, setPageSize] = useState(10)

  // Modals state
  const [selectedDealerForDetails, setSelectedDealerForDetails] = useState<DealerRecord | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [selectedDealerForFollowup, setSelectedDealerForFollowup] = useState<DealerRecord | null>(null)
  const [isFollowupOpen, setIsFollowupOpen] = useState(false)
  const [returnDealerName, setReturnDealerName] = useState('')
  const [isReturnOpen, setIsReturnOpen] = useState(false)

  const filteredDealers = useMemo(() => {
    return dealers.filter((d) => {
      let matchesRadio = true
      if (searchMode === 'distributor' && selectedDistributor !== 'all') {
        matchesRadio = d.distributor.toLowerCase().includes(selectedDistributor.toLowerCase())
      } else if (searchMode === 'dealer_info' && dealerQuery.trim() !== '') {
        matchesRadio =
          d.dealerShop.toLowerCase().includes(dealerQuery.toLowerCase()) ||
          (d.dealerName && d.dealerName.toLowerCase().includes(dealerQuery.toLowerCase())) ||
          (d.dealerCode && d.dealerCode.includes(dealerQuery)) ||
          d.phone.includes(dealerQuery)
      } else if (searchMode === 'city_state' && cityStateQuery.trim() !== '') {
        matchesRadio =
          d.city.toLowerCase().includes(cityStateQuery.toLowerCase()) ||
          d.state.toLowerCase().includes(cityStateQuery.toLowerCase())
      }

      const matchesTable =
        tableSearch.trim() === '' ||
        d.dealerShop.toLowerCase().includes(tableSearch.toLowerCase()) ||
        d.phone.includes(tableSearch) ||
        d.city.toLowerCase().includes(tableSearch.toLowerCase()) ||
        d.distributor.toLowerCase().includes(tableSearch.toLowerCase())

      return matchesRadio && matchesTable
    })
  }, [dealers, searchMode, selectedDistributor, dealerQuery, cityStateQuery, tableSearch])

  const handleExport = () => {
    toast.success('Exporting dealers list to Excel (.xlsx)...')
  }

  const handleReset = () => {
    setSelectedDistributor('all')
    setDealerQuery('')
    setCityStateQuery('')
    setTableSearch('')
    toast.info('Showing All Dealers')
  }

  const handleOpenDetails = (d: DealerRecord) => {
    setSelectedDealerForDetails(d)
    setIsDetailsOpen(true)
  }

  const handleOpenFollowup = (d: DealerRecord) => {
    setSelectedDealerForFollowup(d)
    setIsFollowupOpen(true)
  }

  const handleOpenReturn = (d: DealerRecord) => {
    setReturnDealerName(d.dealerShop)
    setIsReturnOpen(true)
  }

  const handleEditDealer = (d: DealerRecord) => {
    navigate(`/app/dealers/edit/${d.id}`)
  }

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title */}
      <div className="flex items-center justify-between pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Show Dealers</h2>
        <button
          type="button"
          onClick={handleReset}
          className="btn-action-primary text-xs font-bold"
        >
          All Dealer
        </button>
      </div>

      {/* 3 Radio Filter Options matching Screenshot 225541 */}
      <div className="space-y-4 pt-2 max-w-xl">
        {/* Option 1: Select Distributor */}
        <div className="flex items-center gap-3">
          <input
            type="radio"
            id="radioDist"
            name="searchDealerMode"
            checked={searchMode === 'distributor'}
            onChange={() => setSearchMode('distributor')}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 cursor-pointer"
          />
          <div className="flex-1 space-y-1">
            <label htmlFor="radioDist" className="text-xs font-semibold text-[#007bff] cursor-pointer">
              Distributor
            </label>
            <div className="flex items-center gap-3">
              <select
                value={selectedDistributor}
                onChange={(e) => setSelectedDistributor(e.target.value)}
                disabled={searchMode !== 'distributor'}
                className="flex-1 h-9 rounded border border-gray-300 px-3 text-xs text-gray-800 bg-white focus:outline-none focus:border-blue-500 disabled:bg-gray-100"
              >
                <option value="all">Select Distributor</option>
                <option value="VEDA ENTERPRISE">VEDA ENTERPRISE</option>
                <option value="Music Beats">Music Beats</option>
                <option value="Apex Telecom Logistics">Apex Telecom Logistics</option>
                <option value="Delhi Hub Key Distribution">Delhi Hub Key Distribution</option>
              </select>
              <button
                type="button"
                onClick={() => toast.success('Filtered by Distributor')}
                disabled={searchMode !== 'distributor'}
                className="btn-action-primary text-xs font-bold h-9 px-4 disabled:opacity-50"
              >
                search
              </button>
            </div>
          </div>
        </div>

        {/* Option 2: Search Dealer phone/name/shop/Dealercode */}
        <div className="flex items-center gap-3">
          <input
            type="radio"
            id="radioInfo"
            name="searchDealerMode"
            checked={searchMode === 'dealer_info'}
            onChange={() => setSearchMode('dealer_info')}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 cursor-pointer"
          />
          <div className="flex-1 space-y-1">
            <label htmlFor="radioInfo" className="text-xs font-semibold text-[#007bff] cursor-pointer">
              Search Dealer : <span className="text-gray-500 font-normal">(phone/name/shop/Dealercode)</span>
            </label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={dealerQuery}
                onChange={(e) => setDealerQuery(e.target.value)}
                disabled={searchMode !== 'dealer_info'}
                placeholder=""
                className="flex-1 h-9 rounded border border-gray-300 px-3 text-xs text-gray-800 focus:outline-none focus:border-blue-500 disabled:bg-gray-100"
              />
              <button
                type="button"
                onClick={() => toast.success('Filtered by Dealer Information')}
                disabled={searchMode !== 'dealer_info'}
                className="btn-action-primary text-xs font-bold h-9 px-4 disabled:opacity-50"
              >
                search
              </button>
            </div>
          </div>
        </div>

        {/* Option 3: Search Dealer City/State */}
        <div className="flex items-center gap-3">
          <input
            type="radio"
            id="radioCity"
            name="searchDealerMode"
            checked={searchMode === 'city_state'}
            onChange={() => setSearchMode('city_state')}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 cursor-pointer"
          />
          <div className="flex-1 space-y-1">
            <label htmlFor="radioCity" className="text-xs font-semibold text-[#007bff] cursor-pointer">
              Search Dealer : <span className="text-gray-500 font-normal">(City/State)</span>
            </label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={cityStateQuery}
                onChange={(e) => setCityStateQuery(e.target.value)}
                disabled={searchMode !== 'city_state'}
                placeholder=""
                className="flex-1 h-9 rounded border border-gray-300 px-3 text-xs text-gray-800 focus:outline-none focus:border-blue-500 disabled:bg-gray-100"
              />
              <button
                type="button"
                onClick={() => toast.success('Filtered by City/State')}
                disabled={searchMode !== 'city_state'}
                className="btn-action-primary text-xs font-bold h-9 px-4 disabled:opacity-50"
              >
                search
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Export to Excel */}
      <div className="flex justify-end pt-2">
        <button
          type="button"
          onClick={handleExport}
          className="btn-action-success text-xs font-bold"
        >
          Export to Excel
        </button>
      </div>

      {/* Table Controls (Show entries + Search) */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span>entries</span>
        </div>

        <div className="flex items-center gap-2">
          <span>Search:</span>
          <input
            type="text"
            value={tableSearch}
            onChange={(e) => setTableSearch(e.target.value)}
            className="h-8 w-48 rounded border border-gray-300 px-2.5 text-xs focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table matching Screenshot 225541, 235719, and fooloup.png */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left enterprise-table">
          <thead>
            <tr>
              <th className="w-12">Sr No</th>
              <th>Dealer Shop</th>
              <th>Phone</th>
              <th>Last Activation</th>
              <th>Distributor</th>
              <th>City</th>
              <th>Last Billing Date</th>
              <th>Available Keys</th>
              <th>Total Keys</th>
              <th>Login</th>
              <th>Followup</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredDealers.length === 0 ? (
              <tr>
                <td colSpan={12} className="text-center py-8 text-gray-400">
                  No data available in table
                </td>
              </tr>
            ) : (
              filteredDealers.map((d, index) => (
                <tr key={d.id}>
                  <td>{index + 1}</td>
                  <td className="font-bold text-gray-900">{d.dealerShop}</td>
                  <td>{d.phone}</td>
                  <td className="text-xs text-gray-600">{d.lastActivation}</td>
                  <td className="text-xs font-semibold text-blue-600">{d.distributor}</td>
                  <td>{d.city}</td>
                  <td className="text-xs text-gray-600">{d.lastBillingDate}</td>
                  <td className="font-bold text-blue-600">{d.availableKeys}</td>
                  <td className="font-bold text-gray-800">{d.totalKeys}</td>
                  <td>
                    <button
                      type="button"
                      onClick={() => toast.success(`Impersonating ${d.dealerShop} dealer portal...`)}
                      className="p-1 rounded text-purple-600 hover:bg-purple-50"
                      title="Login as Dealer"
                    >
                      <LogIn className="h-4 w-4" />
                    </button>
                  </td>
                  <td>
                    {/* Followup Document Icon matching Screenshot fooloup.png */}
                    <button
                      type="button"
                      onClick={() => handleOpenFollowup(d)}
                      className="p-1 rounded text-gray-700 hover:bg-gray-100 transition-colors"
                      title="View & Add Followup Remarks"
                    >
                      <FileText className="h-4 w-4" />
                    </button>
                  </td>
                  <td>
                    {/* Actions matching Screenshots: Eye (Details), Pencil (Edit), Red Key (Return) */}
                    <div className="flex items-center gap-1.5">
                      {/* Eye: View Dealer Details Modal */}
                      <button
                        type="button"
                        onClick={() => handleOpenDetails(d)}
                        className="p-1.5 rounded-full bg-cyan-100 text-cyan-700 hover:bg-cyan-200 transition-colors"
                        title="View Dealer Details"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </button>

                      {/* Pencil: Edit Dealer Page */}
                      <button
                        type="button"
                        onClick={() => handleEditDealer(d)}
                        className="p-1.5 rounded-full bg-purple-100 text-purple-700 hover:bg-purple-200 transition-colors"
                        title="Edit Dealer Profile"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>

                      {/* Red Key: Key Return / Transfer */}
                      <button
                        type="button"
                        onClick={() => handleOpenReturn(d)}
                        className="p-1.5 rounded-full bg-red-100 text-red-500 hover:bg-red-200 transition-colors"
                        title="Return / Reclaim Keys"
                      >
                        <Key className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>
          Showing {filteredDealers.length === 0 ? 0 : 1} to {filteredDealers.length} of{' '}
          {filteredDealers.length} entries
        </span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Next
          </button>
        </div>
      </div>

      {/* Dealer Details Modal matching Screenshot 235719 */}
      <DealerDetailsModal
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        dealer={selectedDealerForDetails}
      />

      {/* Followup Remarks Modal matching Screenshot fooloup.png */}
      <DealerFollowupModal
        isOpen={isFollowupOpen}
        onClose={() => setIsFollowupOpen(false)}
        dealer={selectedDealerForFollowup}
      />

      {/* Keys Return Modal */}
      <KeysReturnModal
        isOpen={isReturnOpen}
        onClose={() => setIsReturnOpen(false)}
        distributorName={returnDealerName}
      />
    </div>
  )
}
