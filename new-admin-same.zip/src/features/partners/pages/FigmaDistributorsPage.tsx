export { default } from './DistributorsPage'
