import React, { useState } from 'react'
import { toast } from 'sonner'

export default function AddDistributorPage() {
  const [form, setForm] = useState({
    agencyName: '',
    ownerName: '',
    phone: '',
    email: '',
    city: '',
    state: '',
    address: '',
    password: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.agencyName || !form.phone) {
      toast.error('Agency name and phone are required.')
      return
    }
    toast.success(`Distributor "${form.agencyName}" added successfully!`)
    setForm({ agencyName: '', ownerName: '', phone: '', email: '', city: '', state: '', address: '', password: '' })
  }

  return (
    <div className="bg-white p-8 rounded-2xl shadow-xs border border-gray-100 max-w-2xl">
      <div className="pb-4 border-b border-gray-100 mb-6">
        <h2 className="text-xl font-bold text-[#007bff]">Add New Distributor</h2>
        <p className="text-sm text-gray-500 mt-1">Create a new EmiSafe Distributor account</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">Agency Name *</label>
            <input
              type="text"
              name="agencyName"
              value={form.agencyName}
              onChange={handleChange}
              placeholder="Enter agency name"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
              required
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">Owner Name</label>
            <input
              type="text"
              name="ownerName"
              value={form.ownerName}
              onChange={handleChange}
              placeholder="Enter owner name"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">Mobile Number *</label>
            <input
              type="tel"
              name="phone"
              value={form.phone}
              onChange={handleChange}
              placeholder="10-digit mobile number"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
              required
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">Email Address</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="distributor@example.com"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">City</label>
            <input
              type="text"
              name="city"
              value={form.city}
              onChange={handleChange}
              placeholder="Enter city"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">State</label>
            <input
              type="text"
              name="state"
              value={form.state}
              onChange={handleChange}
              placeholder="Enter state"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-1.5 sm:col-span-2">
            <label className="text-xs font-semibold text-[#007bff]">Address</label>
            <textarea
              name="address"
              value={form.address}
              onChange={handleChange}
              placeholder="Enter full address"
              rows={2}
              className="w-full rounded border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#007bff]">Login Password</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="Set distributor password"
              className="w-full h-10 rounded border border-gray-300 px-3 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex gap-3 pt-2">
          <button type="submit" className="btn-figma-blue font-bold px-8 py-2.5 rounded-lg">
            Add Distributor
          </button>
          <button
            type="button"
            onClick={() => setForm({ agencyName: '', ownerName: '', phone: '', email: '', city: '', state: '', address: '', password: '' })}
            className="px-6 py-2.5 rounded-lg border border-gray-300 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors"
          >
            Reset
          </button>
        </div>
      </form>
    </div>
  )
}
