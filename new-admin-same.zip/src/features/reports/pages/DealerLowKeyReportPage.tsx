import { useState, useMemo } from 'react'
import { Key, XCircle, CheckCircle2 } from 'lucide-react'
import { MOCK_DEALERS, type DealerRecord } from '@/mocks/mockSeedData'
import { KeysReturnModal } from '@/components/modals/KeysReturnModal'
import { DealerDetailsModal } from '@/components/modals/DealerDetailsModal'
import { toast } from 'sonner'

export default function DealerLowKeyReportPage() {
  const [dealers, setDealers] = useState<DealerRecord[]>(
    MOCK_DEALERS.filter((d) => d.availableKeys < 4)
  )

  const [mode, setMode] = useState<'dist_date' | 'dist_city' | 'zero_keys'>('dist_city')
  const [selectedDist, setSelectedDist] = useState('VEDA ENTERPRISE')
  const [fromDate, setFromDate] = useState('2026-08-01')
  const [toDate, setToDate] = useState('2026-10-14')
  const [cityQuery, setCityQuery] = useState('')
  const [pageSize, setPageSize] = useState(10)
  const [keyInputValues, setKeyInputValues] = useState<{ [dealerId: string]: string }>({})

  // Modals state
  const [returnDealerName, setReturnDealerName] = useState('')
  const [isReturnOpen, setIsReturnOpen] = useState(false)
  const [selectedDealerForDetails, setSelectedDealerForDetails] = useState<DealerRecord | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)

  const filteredDealers = useMemo(() => {
    return dealers.filter((d) => {
      if (mode === 'zero_keys') {
        return d.availableKeys === 0
      }
      if (mode === 'dist_city') {
        const matchesDist = selectedDist === 'Select Distributor' || d.distributor.includes(selectedDist)
        const matchesCity =
          !cityQuery.trim() ||
          d.city.toLowerCase().includes(cityQuery.toLowerCase()) ||
          d.state.toLowerCase().includes(cityQuery.toLowerCase()) ||
          d.dealerShop.toLowerCase().includes(cityQuery.toLowerCase())
        return matchesDist && matchesCity
      }
      if (mode === 'dist_date') {
        return selectedDist === 'Select Distributor' || d.distributor.includes(selectedDist)
      }
      return true
    })
  }, [dealers, mode, selectedDist, cityQuery])

  // Key Allocation Action (Input + Submit Button matching Screenshot 000738)
  const handleKeyInputChange = (dealerId: string, val: string) => {
    setKeyInputValues({
      ...keyInputValues,
      [dealerId]: val,
    })
  }

  const handleAllocateKeysSubmit = (dealer: DealerRecord) => {
    const val = parseInt(keyInputValues[dealer.id] || '', 10)
    if (isNaN(val) || val <= 0) {
      toast.error('Please enter the number of keys to allocate')
      return
    }

    setDealers(
      dealers.map((d) =>
        d.id === dealer.id
          ? {
              ...d,
              availableKeys: d.availableKeys + val,
              totalKeys: d.totalKeys + val,
            }
          : d
      )
    )

    toast.success(`Allocated ${val} keys to ${dealer.dealerShop}! Available: ${dealer.availableKeys + val}`)
    setKeyInputValues({
      ...keyInputValues,
      [dealer.id]: '',
    })
  }

  const handleToggleLockAccess = (dealer: DealerRecord) => {
    setDealers(
      dealers.map((d) =>
        d.id === dealer.id ? { ...d, lockAccess: !d.lockAccess } : d
      )
    )
    toast.info(`Updated lock access permission for ${dealer.dealerShop}`)
  }

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title matching Screenshot 000738 */}
      <div className="pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-[#007bff]">
          Showing dealers whose key are less than 4
        </h2>
      </div>

      {/* 3 Radio Filters matching Screenshot 000738 */}
      <div className="space-y-4 pt-2">
        {/* Radio 1: Dist + Date Range */}
        <div className="flex items-start sm:items-center gap-3">
          <input
            type="radio"
            id="r1"
            name="dealerReportMode"
            checked={mode === 'dist_date'}
            onChange={() => setMode('dist_date')}
            className="mt-1 sm:mt-0 h-4 w-4 text-blue-600 cursor-pointer"
          />
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="space-y-1">
              <label htmlFor="r1" className="text-[#007bff] font-semibold block cursor-pointer">
                Select Distributor
              </label>
              <select
                value={selectedDist}
                onChange={(e) => setSelectedDist(e.target.value)}
                disabled={mode !== 'dist_date'}
                className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800 disabled:bg-gray-100"
              >
                <option value="Select Distributor">Select Distributor</option>
                <option value="VEDA ENTERPRISE">VEDA ENTERPRISE</option>
                <option value="Music Beats">Music Beats</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[#007bff] font-semibold block">From :</label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                disabled={mode !== 'dist_date'}
                className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800 disabled:bg-gray-100"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[#007bff] font-semibold block">To :</label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                disabled={mode !== 'dist_date'}
                className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800 disabled:bg-gray-100"
              />
            </div>

            <button
              type="button"
              disabled={mode !== 'dist_date'}
              onClick={() => toast.success('Filtered low-key dealers by distributor and date')}
              className="btn-action-primary text-xs font-bold h-9 px-4 mt-5 disabled:opacity-50"
            >
              search
            </button>
          </div>
        </div>

        {/* Radio 2: Dist + City/State matching Screenshot 000738 */}
        <div className="flex items-start sm:items-center gap-3">
          <input
            type="radio"
            id="r2"
            name="dealerReportMode"
            checked={mode === 'dist_city'}
            onChange={() => setMode('dist_city')}
            className="mt-1 sm:mt-0 h-4 w-4 text-blue-600 cursor-pointer"
          />
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="space-y-1">
              <label htmlFor="r2" className="text-[#007bff] font-semibold block cursor-pointer">
                Select Distributor
              </label>
              <select
                value={selectedDist}
                onChange={(e) => setSelectedDist(e.target.value)}
                disabled={mode !== 'dist_city'}
                className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800 disabled:bg-gray-100"
              >
                <option value="Select Distributor">Select Distributor</option>
                <option value="VEDA ENTERPRISE">VEDA ENTERPRISE</option>
                <option value="Music Beats">Music Beats</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[#007bff] font-semibold block">
                Search Dealer : <span className="text-gray-500 font-normal">(City/State)</span>
              </label>
              <input
                type="text"
                value={cityQuery}
                onChange={(e) => setCityQuery(e.target.value)}
                disabled={mode !== 'dist_city'}
                placeholder=""
                className="h-9 w-60 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800 disabled:bg-gray-100"
              />
            </div>

            <button
              type="button"
              disabled={mode !== 'dist_city'}
              onClick={() => toast.success('Filtered low-key dealers by city/state')}
              className="btn-action-primary text-xs font-bold h-9 px-4 mt-5 disabled:opacity-50"
            >
              search
            </button>
          </div>
        </div>

        {/* Radio 3: Having 0 keys matching Screenshot 000738 */}
        <div className="flex items-center gap-3">
          <input
            type="radio"
            id="r3"
            name="dealerReportMode"
            checked={mode === 'zero_keys'}
            onChange={() => setMode('zero_keys')}
            className="h-4 w-4 text-blue-600 cursor-pointer"
          />
          <label htmlFor="r3" className="text-xs font-semibold text-[#007bff] cursor-pointer">
            Search Dealer having 0 keys
          </label>
          <button
            type="button"
            disabled={mode !== 'zero_keys'}
            onClick={() => toast.success('Filtering dealers with 0 available keys')}
            className="btn-action-primary text-xs font-bold h-8 px-4 disabled:opacity-50"
          >
            search
          </button>
        </div>
      </div>

      {/* Export Button matching Screenshot */}
      <div className="flex justify-end pt-1">
        <button
          type="button"
          onClick={() => toast.success('Exporting low-key dealers report to Excel...')}
          className="btn-action-success text-xs font-bold"
        >
          Export to Excel
        </button>
      </div>

      {/* Table Controls */}
      <div className="flex items-center justify-between gap-3 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
          </select>
          <span>entries</span>
        </div>
      </div>

      {/* Table matching Screenshot 000738 */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left enterprise-table">
          <thead>
            <tr>
              <th className="w-10">#</th>
              <th>Create Date</th>
              <th>Shop</th>
              <th>Phone</th>
              <th>City</th>
              <th>State</th>
              <th>Available Keys</th>
              <th>Total Keys</th>
              <th>Last Activation</th>
              <th>Last Billing</th>
              <th>Remark</th>
              <th className="text-center">Lock Access</th>
              <th className="text-center">Keys</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredDealers.length === 0 ? (
              <tr>
                <td colSpan={14} className="text-center py-8 text-gray-400">
                  No dealers matching low-key criteria
                </td>
              </tr>
            ) : (
              filteredDealers.map((d, index) => (
                <tr key={d.id}>
                  <td>{index + 1}</td>
                  <td className="text-xs text-gray-600">{d.createDate || '08/10/2026 16:44:10'}</td>
                  <td>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedDealerForDetails(d)
                        setIsDetailsOpen(true)
                      }}
                      className="font-bold text-gray-900 hover:text-blue-600 hover:underline text-left cursor-pointer"
                    >
                      {d.dealerShop}
                    </button>
                  </td>
                  <td>{d.phone}</td>
                  <td>{d.city}</td>
                  <td>{d.state}</td>
                  <td className="font-bold text-rose-600 text-center">{d.availableKeys}</td>
                  <td className="font-bold text-gray-900 text-center">{d.totalKeys}</td>
                  <td className="text-xs text-gray-600">{d.lastActivation}</td>
                  <td className="text-xs text-gray-600">{d.lastBillingDate}</td>
                  <td className="text-xs text-gray-700 italic">{d.remark || '—'}</td>
                  <td className="text-center">
                    {/* Red 'X' circle icon matching Screenshot 000738 */}
                    <button
                      type="button"
                      onClick={() => handleToggleLockAccess(d)}
                      className="inline-flex items-center justify-center p-1 rounded-full hover:bg-gray-100 transition-colors"
                      title={d.lockAccess ? 'Lock Access Enabled (Click to toggle)' : 'Lock Access Disabled (Click to toggle)'}
                    >
                      {d.lockAccess ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-rose-600" />
                      )}
                    </button>
                  </td>
                  <td className="text-center">
                    {/* Red key icon matching Screenshot 000738 */}
                    <button
                      type="button"
                      onClick={() => {
                        setReturnDealerName(d.dealerShop)
                        setIsReturnOpen(true)
                      }}
                      className="p-1 rounded-full bg-red-100 text-red-500 hover:bg-red-200 transition-colors inline-flex items-center justify-center"
                      title="Return / Adjust Keys"
                    >
                      <Key className="h-4 w-4" />
                    </button>
                  </td>
                  <td>
                    {/* Action with input box + Submit blue button matching Screenshot 000738 */}
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={1}
                        placeholder=""
                        value={keyInputValues[d.id] || ''}
                        onChange={(e) => handleKeyInputChange(d.id, e.target.value)}
                        className="w-16 h-8 rounded border border-gray-300 px-2 text-xs text-center font-bold text-gray-900 focus:outline-none focus:border-blue-500 bg-white"
                      />
                      <button
                        type="button"
                        onClick={() => handleAllocateKeysSubmit(d)}
                        className="btn-action-primary text-xs font-bold h-8 px-3"
                      >
                        Submit
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer matching Screenshot 000738 */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>
          Showing {filteredDealers.length === 0 ? 0 : 1} to {filteredDealers.length} of{' '}
          {filteredDealers.length} entries
        </span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Next
          </button>
        </div>
      </div>

      {/* Keys Return Modal */}
      <KeysReturnModal
        isOpen={isReturnOpen}
        onClose={() => setIsReturnOpen(false)}
        distributorName={returnDealerName}
      />

      {/* Dealer Details Modal */}
      <DealerDetailsModal
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        dealer={selectedDealerForDetails}
      />
    </div>
  )
}
