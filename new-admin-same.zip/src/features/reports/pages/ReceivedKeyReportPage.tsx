import { useState } from 'react'
import { MOCK_RECEIVED_REPORTS } from '@/mocks/mockSeedData'

export default function ReceivedKeyReportPage() {
  const [reports] = useState(MOCK_RECEIVED_REPORTS)
  const [pageSize, setPageSize] = useState(10)
  const [tableSearch, setTableSearch] = useState('')

  const filtered = reports.filter(
    (r) =>
      tableSearch.trim() === '' ||
      r.receivedFrom.toLowerCase().includes(tableSearch.toLowerCase()) ||
      r.transactionDate.includes(tableSearch)
  )

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title */}
      <div className="pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Key Received reports</h2>
      </div>

      {/* Table Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
          </select>
          <span>entries</span>
        </div>

        <div className="flex items-center gap-2">
          <span>Search:</span>
          <input
            type="text"
            value={tableSearch}
            onChange={(e) => setTableSearch(e.target.value)}
            className="h-8 w-48 rounded border border-gray-300 px-2.5 text-xs focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left enterprise-table">
          <thead>
            <tr>
              <th className="w-12">#</th>
              <th>Transaction Date</th>
              <th>Received from</th>
              <th>No of keys</th>
              <th>key Price</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, index) => (
              <tr key={r.id}>
                <td>{index + 1}</td>
                <td className="text-xs text-gray-600">{r.transactionDate}</td>
                <td className="font-bold text-gray-900">{r.receivedFrom}</td>
                <td className="font-bold text-gray-900">{r.noOfKeys}</td>
                <td className="font-mono text-xs text-gray-800">{r.keyPrice}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>Showing 1 to {filtered.length} of {filtered.length} entries</span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-600 hover:bg-gray-50">
            2
          </button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-600 hover:bg-gray-50">
            Next
          </button>
        </div>
      </div>
    </div>
  )
}
