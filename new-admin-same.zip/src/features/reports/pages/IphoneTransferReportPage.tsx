import { useState } from 'react'
import { Printer } from 'lucide-react'
import { toast } from 'sonner'

const MOCK_IPHONE_TRANSFER = [
  { id: 'it_1', srNo: 1, sendBy: 'VEDA ENTERPRISE', transferTo: 'MOBILE SHOPI', noOfKeys: 10, keyPrice: 600, transactionDate: '22-09-2026 21:30:59' },
  { id: 'it_2', srNo: 2, sendBy: 'VEDA ENTERPRISE', transferTo: 'MOBILE SHOPI', noOfKeys: 10, keyPrice: 600, transactionDate: '22-09-2026 21:32:12' },
  { id: 'it_3', srNo: 3, sendBy: 'VEDA ENTERPRISE', transferTo: 'IRFAN MOBILE CARE CENTER', noOfKeys: 97, keyPrice: 600, transactionDate: '03-09-2026 18:12:03' },
  { id: 'it_4', srNo: 4, sendBy: 'VEDA ENTERPRISE', transferTo: 'IRFAN MOBILE CARE CENTER', noOfKeys: 3, keyPrice: 600, transactionDate: '03-09-2026 18:13:33' },
]

export default function IphoneTransferReportPage() {
  const [activeTab, setActiveTab] = useState<'stockist_dist' | 'dist_dealer'>('dist_dealer')
  const [fromDate, setFromDate] = useState('2026-01-14')
  const [toDate, setToDate] = useState('2026-10-01')
  const [tableSearch, setTableSearch] = useState('')
  const [pageSize, setPageSize] = useState(10)

  const filtered = MOCK_IPHONE_TRANSFER.filter((r) =>
    tableSearch.trim() === '' ||
    r.transferTo.toLowerCase().includes(tableSearch.toLowerCase()) ||
    r.sendBy.toLowerCase().includes(tableSearch.toLowerCase())
  )

  const todaySell = 0
  const weeklySell = 10
  const monthlySell = 10

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Iphone Key Transaction reports</h2>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('stockist_dist')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all shadow-xs ${
              activeTab === 'stockist_dist'
                ? 'bg-[#009688] text-white ring-2 ring-teal-400'
                : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
            }`}
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Stockiest To Distributor</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('dist_dealer')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all shadow-xs ${
              activeTab === 'dist_dealer'
                ? 'bg-[#fbc02d] text-gray-900 ring-2 ring-amber-400'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100'
            }`}
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Distributor To Dealer</span>
          </button>
        </div>
      </div>

      {/* Subheader */}
      <h3 className="text-sm font-bold text-blue-600">
        {activeTab === 'stockist_dist' ? 'Stockiest To Distributor' : 'Distributor To Dealer'}
      </h3>

      {/* 3 Yellow Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl">
        <div className="card-stat-yellow p-6 text-center shadow-xs">
          <p className="text-sm font-bold text-gray-800">Today Sell</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{todaySell}</p>
        </div>
        <div className="card-stat-yellow p-6 text-center shadow-xs">
          <p className="text-sm font-bold text-gray-800">Weekly Sell</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{weeklySell}</p>
        </div>
        <div className="card-stat-yellow p-6 text-center shadow-xs">
          <p className="text-sm font-bold text-gray-800">Monthly Sell</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{monthlySell}</p>
        </div>
      </div>

      {/* Date Filters */}
      <div className="flex flex-wrap items-end gap-4 pt-2">
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#007bff]">From :</label>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800"
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#007bff]">To :</label>
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800"
          />
        </div>
        <button
          type="button"
          onClick={() => toast.success('Filtered iPhone transfer transactions')}
          className="btn-figma-blue text-xs font-bold h-9 px-6"
        >
          search
        </button>
        <button
          type="button"
          onClick={() => toast.info('Loading today iPhone transfer records...')}
          className="btn-figma-blue text-xs font-bold h-9 px-6"
        >
          Today Data
        </button>
      </div>

      {/* Table Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span>entries</span>
        </div>
        <div className="flex items-center gap-2">
          <span>Search:</span>
          <input
            type="text"
            value={tableSearch}
            onChange={(e) => setTableSearch(e.target.value)}
            className="h-8 w-48 rounded border border-gray-300 px-2.5 text-xs focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left figma-table">
          <thead>
            <tr>
              <th className="w-16">Sr No.</th>
              <th>Transaction Date</th>
              <th>Send By</th>
              <th>Transfer to /Return from</th>
              <th>No of keys</th>
              <th>key Price</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-8 text-gray-400">
                  No data available in table
                </td>
              </tr>
            ) : (
              filtered.map((r) => (
                <tr key={r.id}>
                  <td>{r.srNo}</td>
                  <td className="text-xs text-gray-600">{r.transactionDate}</td>
                  <td className="font-bold text-gray-900">{r.sendBy}</td>
                  <td className="text-gray-800">{r.transferTo}</td>
                  <td className="font-bold text-gray-900">{r.noOfKeys}</td>
                  <td className="font-mono text-xs text-gray-800">{r.keyPrice}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>Showing 1 to {filtered.length} of {filtered.length} entries</span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">Previous</button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">Next</button>
        </div>
      </div>
    </div>
  )
}
