import { useState } from 'react'
import { Printer } from 'lucide-react'
import {
  MOCK_TRANSFER_REPORTS,
  MOCK_DISTRIBUTOR_TO_DEALER_TRANSFERS,
  type TransferReportItem,
} from '@/mocks/mockSeedData'
import { InvoiceReceiptModal } from '@/components/modals/InvoiceReceiptModal'
import { toast } from 'sonner'

export default function TransferReportPage() {
  const [activeTab, setActiveTab] = useState<'stockist_dist' | 'dist_dealer'>('stockist_dist')
  const [fromDate, setFromDate] = useState('2026-01-15')
  const [toDate, setToDate] = useState('2026-10-15')
  const [pageSize, setPageSize] = useState(10)
  const [tableSearch, setTableSearch] = useState('')

  // Invoice Receipt Modal state
  const [selectedInvoiceItem, setSelectedInvoiceItem] = useState<TransferReportItem | null>(null)
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false)

  const rawReports = activeTab === 'stockist_dist'
    ? MOCK_TRANSFER_REPORTS
    : MOCK_DISTRIBUTOR_TO_DEALER_TRANSFERS

  const filteredReports = rawReports.filter(
    (r) =>
      tableSearch.trim() === '' ||
      r.transferTo.toLowerCase().includes(tableSearch.toLowerCase()) ||
      r.transactionDate.includes(tableSearch) ||
      (r.sendBy && r.sendBy.toLowerCase().includes(tableSearch.toLowerCase()))
  )

  const handleOpenInvoice = (item: TransferReportItem) => {
    setSelectedInvoiceItem(item)
    setIsInvoiceOpen(true)
  }

  const handleTodayData = () => {
    const today = new Date().toISOString().split('T')[0]
    setFromDate(today)
    setToDate(today)
    toast.info('Displaying transfers recorded for today')
  }

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title & Tabs matching Screenshot 000919 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Key Transaction Reports</h2>

        <div className="flex items-center gap-2">
          {/* Stockiest To Distributor (Teal Pill with Print icon) */}
          <button
            type="button"
            onClick={() => setActiveTab('stockist_dist')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all shadow-xs ${
              activeTab === 'stockist_dist'
                ? 'bg-[#009688] text-white ring-2 ring-teal-400'
                : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
            }`}
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Stockiest To Distributor</span>
          </button>

          {/* Distributor To Dealer (Yellow Pill with Print icon) */}
          <button
            type="button"
            onClick={() => setActiveTab('dist_dealer')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all shadow-xs ${
              activeTab === 'dist_dealer'
                ? 'bg-[#fbc02d] text-gray-900 ring-2 ring-amber-400'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100'
            }`}
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Distributor To Dealer</span>
          </button>
        </div>
      </div>

      {/* Subheader */}
      <h3 className="text-sm font-bold text-blue-600">
        {activeTab === 'stockist_dist' ? 'Stockiest To Distributor' : 'Distributor To Dealer'}
      </h3>

      {/* 3 Yellow Summary Cards matching Screenshot 000919 */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl">
        <div className="card-stat-yellow p-6 text-center shadow-xs">
          <p className="text-sm font-bold text-gray-800">Today Sell</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">0</p>
        </div>

        <div className="card-stat-yellow p-6 text-center shadow-xs">
          <p className="text-sm font-bold text-gray-800">Weekly Sell</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">0</p>
        </div>

        <div className="card-stat-yellow p-6 text-center shadow-xs">
          <p className="text-sm font-bold text-gray-800">Monthly Sell</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">0</p>
        </div>
      </div>

      {/* Date Filters matching Screenshot 000919 */}
      <div className="flex flex-wrap items-end gap-4 pt-2">
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#007bff]">From :</label>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800"
          />
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#007bff]">To :</label>
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="h-9 rounded border border-gray-300 px-3 text-xs bg-white text-gray-800"
          />
        </div>

        <button
          type="button"
          onClick={() => toast.success('Filtered transactions by selected date range')}
          className="btn-action-primary text-xs font-bold h-9 px-6"
        >
          search
        </button>

        <button
          type="button"
          onClick={handleTodayData}
          className="btn-action-primary text-xs font-bold h-9 px-6"
        >
          Today Data
        </button>
      </div>

      {/* Table Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
          </select>
          <span>entries</span>
        </div>

        <div className="flex items-center gap-2">
          <span>Search:</span>
          <input
            type="text"
            value={tableSearch}
            onChange={(e) => setTableSearch(e.target.value)}
            className="h-8 w-48 rounded border border-gray-300 px-2.5 text-xs focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table matching Screenshot 000919 */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left enterprise-table">
          <thead>
            <tr>
              <th className="w-12">#</th>
              <th>Transaction Date</th>
              <th>Transfer to / Return from</th>
              <th>No of keys</th>
              <th>Remark</th>
              <th>Key Price</th>
              <th className="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredReports.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-8 text-gray-400">
                  No transaction records found
                </td>
              </tr>
            ) : (
              filteredReports.map((r, index) => (
                <tr key={r.id}>
                  <td>{index + 1}</td>
                  <td className="text-xs text-gray-600">{r.transactionDate}</td>
                  <td className="font-bold text-gray-900">{r.transferTo}</td>
                  <td className="font-bold text-gray-900">{r.noOfKeys}</td>
                  <td className="text-xs text-gray-500">{r.remark || '—'}</td>
                  <td className="font-mono text-xs text-gray-800 font-semibold">{r.keyPrice}</td>
                  <td className="text-center">
                    {/* Exact red PDF invoice icon matching Screenshot 000919 */}
                    <button
                      type="button"
                      onClick={() => handleOpenInvoice(r)}
                      className="p-1 rounded text-red-600 hover:bg-red-50 transition-colors inline-flex items-center justify-center"
                      title="View & Download Transfer Invoice Receipt PDF"
                    >
                      <div className="h-6 w-5 border border-red-600 rounded bg-white flex flex-col items-center justify-center p-0.5 shadow-xs">
                        <span className="text-[7px] font-black text-red-600 leading-none">PDF</span>
                        <div className="w-3 h-0.5 bg-red-400 mt-0.5" />
                      </div>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer matching Screenshot 000919 */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>
          Showing 1 to {filteredReports.length} of {filteredReports.length} entries
        </span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Next
          </button>
        </div>
      </div>

      {/* Invoice Receipt Modal */}
      <InvoiceReceiptModal
        isOpen={isInvoiceOpen}
        onClose={() => setIsInvoiceOpen(false)}
        item={selectedInvoiceItem}
      />
    </div>
  )
}
