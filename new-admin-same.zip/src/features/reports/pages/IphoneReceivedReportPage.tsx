import { useState } from 'react'

const MOCK_IPHONE_RECEIVED = [
  { id: 'ir_1', transactionDate: '06-07-2026 16:17:16', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 500, keyPrice: 70 },
  { id: 'ir_2', transactionDate: '19-12-2025 11:13:47', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 400, keyPrice: 0 },
  { id: 'ir_3', transactionDate: '27-11-2025 18:24:38', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 50, keyPrice: 0 },
  { id: 'ir_4', transactionDate: '15-09-2025 17:34:51', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 2000, keyPrice: 70 },
  { id: 'ir_5', transactionDate: '03-06-2025 15:40:04', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 1000, keyPrice: 75 },
  { id: 'ir_6', transactionDate: '27-11-2024 18:26:16', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 555, keyPrice: 0 },
  { id: 'ir_7', transactionDate: '16-11-2024 11:23:45', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 270, keyPrice: 0 },
  { id: 'ir_8', transactionDate: '28-10-2024 21:49:41', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 2000, keyPrice: 110 },
  { id: 'ir_9', transactionDate: '09-08-2024 11:20:19', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 660, keyPrice: 110 },
  { id: 'ir_10', transactionDate: '08-08-2024 20:45:57', receivedFrom: 'HBT EMPLOYEE FAIYAZ', noOfKeys: 500, keyPrice: 110 },
]

export default function IphoneReceivedReportPage() {
  const [tableSearch, setTableSearch] = useState('')
  const [pageSize, setPageSize] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)

  const filtered = MOCK_IPHONE_RECEIVED.filter((r) =>
    tableSearch.trim() === '' ||
    r.receivedFrom.toLowerCase().includes(tableSearch.toLowerCase()) ||
    r.transactionDate.includes(tableSearch)
  )

  const totalPages = Math.ceil(filtered.length / pageSize)
  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title */}
      <div className="pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Key Received reports</h2>
      </div>

      {/* Table Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1) }}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span>entries</span>
        </div>
        <div className="flex items-center gap-2">
          <span>Search:</span>
          <input
            type="text"
            value={tableSearch}
            onChange={(e) => { setTableSearch(e.target.value); setCurrentPage(1) }}
            className="h-8 w-48 rounded border border-gray-300 px-2.5 text-xs focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table matching Screenshot 230150 */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left figma-table">
          <thead>
            <tr>
              <th className="w-12">#</th>
              <th>Transaction Date</th>
              <th>Received from</th>
              <th>No of keys</th>
              <th>key Price</th>
            </tr>
          </thead>
          <tbody>
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-8 text-gray-400">
                  No data available in table
                </td>
              </tr>
            ) : (
              paginated.map((r, i) => (
                <tr key={r.id} className={i % 2 === 1 ? 'bg-gray-50' : ''}>
                  <td>{(currentPage - 1) * pageSize + i + 1}</td>
                  <td className="font-medium text-[#007bff] text-xs">{r.transactionDate}</td>
                  <td className="font-bold text-gray-900">{r.receivedFrom}</td>
                  <td className="font-bold text-gray-900">{r.noOfKeys}</td>
                  <td className={`font-mono text-xs ${r.keyPrice === 0 ? 'text-[#007bff]' : 'text-gray-800'}`}>
                    {r.keyPrice}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer with Pagination */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>
          Showing {filtered.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} to{' '}
          {Math.min(currentPage * pageSize, filtered.length)} of {filtered.length} entries
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className="px-3 py-1 rounded border border-gray-200 text-gray-400 disabled:cursor-not-allowed hover:bg-gray-50"
          >
            Previous
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => setCurrentPage(p)}
              className={`px-3 py-1 rounded font-bold ${
                p === currentPage ? 'bg-[#007bff] text-white' : 'border border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {p}
            </button>
          ))}
          <button
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            className="px-3 py-1 rounded border border-gray-200 text-gray-400 disabled:cursor-not-allowed hover:bg-gray-50"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  )
}
