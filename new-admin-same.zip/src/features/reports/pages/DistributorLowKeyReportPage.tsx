import { useState } from 'react'
import { Key } from 'lucide-react'
import { MOCK_DISTRIBUTORS, type DistributorRecord } from '@/mocks/mockSeedData'
import { KeyStatusModal, type KeyStatusData } from '@/components/modals/KeyStatusModal'
import { KeysReturnModal } from '@/components/modals/KeysReturnModal'
import { toast } from 'sonner'

export default function DistributorLowKeyReportPage() {
  const [distributors, setDistributors] = useState<DistributorRecord[]>(
    MOCK_DISTRIBUTORS.filter((d) => d.availableKeys < 40)
  )
  const [remarks, setRemarks] = useState<Record<string, string>>({
    dist_1: 'baad me lenge',
    dist_2: '',
  })
  const [onlyZeroKeys, setOnlyZeroKeys] = useState(false)
  const [pageSize, setPageSize] = useState(10)

  // Modals state
  const [keyStatusData, setKeyStatusData] = useState<KeyStatusData | null>(null)
  const [isKeyStatusOpen, setIsKeyStatusOpen] = useState(false)
  const [returnDistributor, setReturnDistributor] = useState<string>('')
  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false)

  const handleRemarkSubmit = (distId: string, agencyName: string) => {
    const text = remarks[distId] || ''
    setDistributors(
      distributors.map((d) => (d.id === distId ? { ...d, remark: text } : d))
    )
    toast.success(`Remark updated for ${agencyName}: "${text}"`)
  }

  const handleOpenKeyStatus = (d: DistributorRecord) => {
    setKeyStatusData({
      agencyName: d.agency,
      totalKeys: d.totalKeys || 5810,
      usedKeys: d.usedKeys || 5810,
      availableKeys: d.availableKeys || 0,
    })
    setIsKeyStatusOpen(true)
  }

  const handleOpenReturn = (d: DistributorRecord) => {
    setReturnDistributor(d.agency)
    setIsReturnModalOpen(true)
  }

  const displayedDistributors = onlyZeroKeys
    ? distributors.filter((d) => d.availableKeys === 0)
    : distributors

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title matching Screenshot 235321 and 225859 */}
      <div className="pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-[#007bff]">
          Showing Distributor whose key are less than 40
        </h2>
      </div>

      {/* Top filter: Search Distributor having 0 keys */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-gray-700">
            Search Distributor having 0 keys
          </span>
          <button
            type="button"
            onClick={() => {
              setOnlyZeroKeys(!onlyZeroKeys)
              toast.info(onlyZeroKeys ? 'Showing all low-key distributors' : 'Filtering 0 key distributors')
            }}
            className="btn-action-primary text-xs font-bold h-8 px-4"
          >
            Search
          </button>
        </div>

        {/* Green Export button */}
        <button
          type="button"
          onClick={() => toast.success('Exporting Low-Key Distributors to Excel (.xlsx)...')}
          className="btn-action-success text-xs font-bold"
        >
          Export to Excel
        </button>
      </div>

      {/* Table Controls */}
      <div className="flex items-center justify-between gap-3 pt-2 text-xs text-gray-600">
        <div className="flex items-center gap-2">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            className="h-8 rounded border border-gray-300 px-2 bg-white text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
          </select>
          <span>entries</span>
        </div>
      </div>

      {/* Table matching Screenshot 235321 */}
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full text-left enterprise-table">
          <thead>
            <tr>
              <th className="w-10">#</th>
              <th>Agency</th>
              <th>Phone</th>
              <th>City</th>
              <th>State</th>
              <th>Last Billing</th>
              <th>Remark</th>
              <th>Available Keys</th>
              <th>Total Keys</th>
              <th>Keys</th>
              <th className="min-w-[200px]">Action</th>
            </tr>
          </thead>
          <tbody>
            {displayedDistributors.map((d, index) => (
              <tr key={d.id}>
                <td>{index + 1}</td>
                <td className="font-bold text-gray-900">{d.agency}</td>
                <td>{d.phone}</td>
                <td>{d.city}</td>
                <td>{d.state}</td>
                <td className="text-xs text-gray-600">{d.lastBillingDate}</td>
                <td className="text-xs text-gray-700 italic">{d.remark || '—'}</td>
                <td className="font-bold text-gray-900 text-center">{d.availableKeys}</td>
                <td className="font-bold text-gray-900 text-center">{d.totalKeys}</td>
                <td>
                  {/* Clickable 3 keys matching Screenshot 235321 */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenKeyStatus(d)}
                      className="h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center hover:bg-blue-200 transition-colors"
                      title="View Key Status"
                    >
                      <Key className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenReturn(d)}
                      className="h-6 w-6 rounded-full bg-red-100 text-red-500 flex items-center justify-center hover:bg-red-200 transition-colors"
                      title="Return Keys"
                    >
                      <Key className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => toast.info(`Issuing quota for ${d.agency}`)}
                      className="h-6 w-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center hover:bg-green-200 transition-colors"
                      title="Allocate Keys"
                    >
                      <Key className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
                <td>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={remarks[d.id] ?? d.remark ?? ''}
                      onChange={(e) =>
                        setRemarks({ ...remarks, [d.id]: e.target.value })
                      }
                      placeholder="Enter Remark"
                      className="h-8 rounded border border-gray-300 px-2 text-xs text-gray-800 w-28 focus:outline-none focus:border-blue-500 bg-white"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemarkSubmit(d.id, d.agency)}
                      className="btn-action-primary text-xs font-bold h-8 px-3"
                    >
                      Submit
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-500 pt-2">
        <span>Showing 1 to {displayedDistributors.length} of {displayedDistributors.length} entries</span>
        <div className="flex items-center gap-1">
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button className="px-3 py-1 rounded bg-[#007bff] text-white font-bold">1</button>
          <button className="px-3 py-1 rounded border border-gray-200 text-gray-400 cursor-not-allowed">
            Next
          </button>
        </div>
      </div>

      {/* Key Status Modal matching Screenshot 235321 */}
      <KeyStatusModal
        isOpen={isKeyStatusOpen}
        onClose={() => setIsKeyStatusOpen(false)}
        data={keyStatusData}
      />

      {/* Keys Return Modal matching Screenshot 235354 */}
      <KeysReturnModal
        isOpen={isReturnModalOpen}
        onClose={() => setIsReturnModalOpen(false)}
        distributorName={returnDistributor}
      />
    </div>
  )
}
