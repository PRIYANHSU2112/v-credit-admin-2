import React, { useState } from 'react'
import { toast } from 'sonner'

export default function IphoneKeyPriceSettingPage() {
  const [oldPrice] = useState('600')
  const [newPrice, setNewPrice] = useState('')

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newPrice) {
      toast.error('Please enter a new iPhone key price.')
      return
    }
    toast.success(`iPhone key price updated to ₹${newPrice} per key successfully!`)
    setNewPrice('')
  }

  return (
    <div className="bg-white p-8 rounded-2xl shadow-xs border border-gray-100 max-w-2xl">
      {/* Title */}
      <div className="pb-4 border-b border-gray-100 mb-6">
        <h2 className="text-xl font-bold text-gray-800">Iphone Key Price Setting</h2>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Old Key Price */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Old Key Price</label>
          <input
            type="text"
            value={oldPrice}
            disabled
            className="w-full h-11 rounded-lg border border-gray-200 px-4 text-sm bg-gray-50 text-gray-500 cursor-not-allowed"
          />
        </div>

        {/* New iPhone Key Price */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Per Iphone Key Price</label>
          <input
            type="number"
            placeholder="Enter Price per Iphone key"
            value={newPrice}
            onChange={(e) => setNewPrice(e.target.value)}
            min="0"
            step="0.01"
            className="w-full h-11 rounded-lg border border-gray-300 px-4 text-sm bg-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="btn-figma-blue font-bold px-8 py-2.5 rounded-lg"
        >
          Save Changes
        </button>
      </form>
    </div>
  )
}
