import { useState } from 'react'
import { PageHeader } from '@/components/layout/PageHeader'
import { Card, CardTitle, CardDescription } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Switch } from '@/components/ui/Switch'
import { toast } from 'sonner'

export default function SettingsPage() {

  const [autoLockOnOverdue, setAutoLockOnOverdue] = useState(true)
  const [gracePeriodDays, setGracePeriodDays] = useState('3')
  const [smsGatewayActive, setSmsGatewayActive] = useState(true)
  const [whatsappAlerts, setWhatsappAlerts] = useState(true)

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success('Platform configurations saved successfully.')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Settings & System Configurations"
        subtitle="Manage MDM enforcement rules, SMS/WhatsApp gateways, and partner policy thresholds."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* MDM Enforcement Policy */}
        <Card className="p-6 space-y-4">
          <CardTitle>MDM & Auto-Lock Policies</CardTitle>
          <CardDescription>
            Enforce device lock automatically when borrowers miss EMI due dates
          </CardDescription>

          <form onSubmit={handleSave} className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-foreground">Auto-Lock on Overdue</p>
                <p className="text-xs text-muted-foreground">Trigger MDM lock after grace period expires</p>
              </div>
              <Switch checked={autoLockOnOverdue} onChange={setAutoLockOnOverdue} />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-foreground">
                Grace Period (Days Before Lock)
              </label>
              <Input
                type="number"
                value={gracePeriodDays}
                onChange={(e) => setGracePeriodDays(e.target.value)}
                min="0"
                max="30"
              />
            </div>

            <Button type="submit" variant="primary" size="sm">
              Save Policy Changes
            </Button>
          </form>
        </Card>

        {/* Messaging & SMS Gateways */}
        <Card className="p-6 space-y-4">
          <CardTitle>Notification Channels</CardTitle>
          <CardDescription>
            Manage borrower EMI reminders and security notifications
          </CardDescription>

          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-foreground">SMS Reminder Gateway</p>
                <p className="text-xs text-muted-foreground">Send DLT approved SMS for upcoming EMIs</p>
              </div>
              <Switch checked={smsGatewayActive} onChange={setSmsGatewayActive} />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-foreground">WhatsApp Business API</p>
                <p className="text-xs text-muted-foreground">Send interactive UPI payment links on WhatsApp</p>
              </div>
              <Switch checked={whatsappAlerts} onChange={setWhatsappAlerts} />
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => toast.success('Test message dispatched successfully.')}
            >
              Test Notification Dispatch
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
