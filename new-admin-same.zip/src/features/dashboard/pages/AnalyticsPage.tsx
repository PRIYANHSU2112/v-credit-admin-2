import { useState } from 'react'
import { toast } from 'sonner'

// Mock data for Super Analytics page (Screenshot 230745)
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const YEARS = ['2024', '2025', '2026']

// Simulated bar chart data for users activated per day
const generateDayData = (total: number) =>
  Array.from({ length: 31 }, (_, i) => ({
    day: String(i + 1).padStart(2, '0'),
    value: Math.random() < 0.4 ? 0 : Math.floor(Math.random() * (total / 10)) + 1,
  }))

export default function AnalyticsPage() {
  const [usersYear, setUsersYear] = useState('2021')
  const [usersMonth, setUsersMonth] = useState('October')
  const [salesYear, setSalesYear] = useState('2026')
  const [salesMonth, setSalesMonth] = useState('August')

  const [userData] = useState(generateDayData(46))
  const [salesData] = useState(generateDayData(500))

  const totalUsers = 46
  const totalSales = 500

  const maxUserValue = Math.max(...userData.map((d) => d.value), 5)
  const maxSalesValue = Math.max(...salesData.map((d) => d.value), 500)

  const COLORS = ['#ef9a9a', '#f48fb1', '#ce93d8', '#b39ddb', '#90caf9', '#80deea', '#a5d6a7', '#e6ee9c', '#ffe082', '#ffcc80', '#bcaaa4']

  return (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
      {/* Title */}
      <div className="pb-2 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Super Analytics</h2>
      </div>

      {/* Two Charts Side by Side */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Users Activated Chart */}
        <div className="border border-gray-200 rounded-xl p-4 space-y-4">
          {/* Controls */}
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-gray-600 font-medium">Select Year</span>
              <select
                value={usersYear}
                onChange={(e) => setUsersYear(e.target.value)}
                className="h-7 rounded border border-gray-300 px-2 bg-white text-xs"
              >
                {['2021', '2022', '2023', '2024', '2025', '2026'].map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-gray-600 font-medium">Select Month</span>
              <select
                value={usersMonth}
                onChange={(e) => setUsersMonth(e.target.value)}
                className="h-7 rounded border border-gray-300 px-2 bg-white text-xs"
              >
                {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>

            <button
              type="button"
              onClick={() => toast.info(`Showing user activations for ${usersMonth} ${usersYear}`)}
              className="btn-figma-blue text-xs font-bold h-7 px-4"
            >
              Search
            </button>

            <span className="text-gray-700 font-bold ml-2">
              Total Users : <span className="text-gray-900">{totalUsers}</span>
            </span>
          </div>

          {/* Bar Chart */}
          <div className="relative">
            <div className="text-[10px] text-gray-500 text-center mb-2 flex items-center justify-center gap-2">
              <span className="inline-block w-4 h-2 rounded" style={{ background: '#ef9a9a' }} />
              Number of Users Activated
            </div>
            <div className="overflow-x-auto">
              <div className="flex items-end gap-0.5 h-48 min-w-max px-2" style={{ minWidth: '400px' }}>
                {userData.map((d, i) => {
                  const barH = d.value === 0 ? 2 : Math.max(8, (d.value / maxUserValue) * 160)
                  return (
                    <div key={d.day} className="flex flex-col items-center gap-0.5">
                      <div
                        className="rounded-t transition-all duration-300"
                        style={{
                          width: '10px',
                          height: `${barH}px`,
                          background: COLORS[i % COLORS.length],
                        }}
                        title={`Day ${d.day}: ${d.value}`}
                      />
                      <span className="text-[8px] text-gray-400">{d.day}</span>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Y-axis labels */}
            <div className="absolute left-0 top-6 flex flex-col justify-between h-48 text-[9px] text-gray-400 pointer-events-none">
              {[5, 4, 3, 2, 1, 0].map((v) => (
                <span key={v}>{((v / 5) * maxUserValue).toFixed(1)}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Keys Sold Chart */}
        <div className="border border-gray-200 rounded-xl p-4 space-y-4">
          {/* Controls */}
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-gray-600 font-medium">Select Year</span>
              <select
                value={salesYear}
                onChange={(e) => setSalesYear(e.target.value)}
                className="h-7 rounded border border-gray-300 px-2 bg-white text-xs"
              >
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-gray-600 font-medium">Select Month</span>
              <select
                value={salesMonth}
                onChange={(e) => setSalesMonth(e.target.value)}
                className="h-7 rounded border border-gray-300 px-2 bg-white text-xs"
              >
                {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>

            <button
              type="button"
              onClick={() => toast.info(`Showing key sales for ${salesMonth} ${salesYear}`)}
              className="btn-figma-blue text-xs font-bold h-7 px-4"
            >
              Search
            </button>

            <span className="text-gray-700 font-bold ml-2">
              Total Sales : <span className="text-gray-900">{totalSales}</span>
            </span>
          </div>

          {/* Bar Chart */}
          <div className="relative">
            <div className="text-[10px] text-gray-500 text-center mb-2 flex items-center justify-center gap-2">
              <span className="inline-block w-4 h-2 rounded" style={{ background: '#ef9a9a' }} />
              Number of Keys Sold
            </div>
            <div className="overflow-x-auto">
              <div className="flex items-end gap-0.5 h-48 min-w-max px-2" style={{ minWidth: '400px' }}>
                {salesData.map((d, i) => {
                  const barH = d.value === 0 ? 2 : Math.max(8, (d.value / maxSalesValue) * 160)
                  return (
                    <div key={d.day} className="flex flex-col items-center gap-0.5">
                      <div
                        className="rounded-t transition-all duration-300"
                        style={{
                          width: '10px',
                          height: `${barH}px`,
                          background: COLORS[i % COLORS.length],
                        }}
                        title={`Day ${d.day}: ${d.value}`}
                      />
                      <span className="text-[8px] text-gray-400">{d.day}</span>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Y-axis */}
            <div className="absolute left-0 top-6 flex flex-col justify-between h-48 text-[9px] text-gray-400 pointer-events-none">
              {[5, 4, 3, 2, 1, 0].map((v) => (
                <span key={v}>{Math.round((v / 5) * maxSalesValue)}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
