import { useNavigate } from 'react-router-dom'
import {
  Users,
  User,
  Key,
} from 'lucide-react'
import { DEFAULT_DASHBOARD_STATS, type DashboardStats } from '@/mocks/mockSeedData'
import { ROUTE_PATHS } from '@/app/routes/routePaths'
import { useAppSelector } from '@/app/store/hooks'
import type { UserRole } from '@/types/user'

export default function DashboardPage() {
  const navigate = useNavigate()
  const { user } = useAppSelector((state) => state.auth)

  const role = user?.role || 'super_admin'
  const isSuper = role === 'super_admin'
  const isStockist = role === 'stockist' || isSuper
  const isDistributor = role === 'distributor' || isStockist

  // Role-tailored mock stats reflecting the hierarchy chain
  const roleStatsMap: Record<UserRole, DashboardStats> = {
    super_admin: DEFAULT_DASHBOARD_STATS,
    sub_admin: DEFAULT_DASHBOARD_STATS,
    stockist: {
      ...DEFAULT_DASHBOARD_STATS,
      distributorCount: 2,
      dealerCount: 42,
      userCount: 4890,
      removeUserCount: 1204,
      totalKeys: 6500,
      transferedKeys: 6420,
      balanceKeys: 80,
      totalIphoneKeys: 250,
      transferIphoneKeys: 120,
      balanceIphoneKeys: 130,
    },
    distributor: {
      ...DEFAULT_DASHBOARD_STATS,
      dealerCount: 18,
      userCount: 1840,
      removeUserCount: 412,
      totalKeys: 2400,
      transferedKeys: 2360,
      balanceKeys: 40,
      totalIphoneKeys: 80,
      transferIphoneKeys: 35,
      balanceIphoneKeys: 45,
    },
    dealer: {
      ...DEFAULT_DASHBOARD_STATS,
      userCount: 245,
      removeUserCount: 38,
      today30UserCount: 2,
      todayRunningUserCount: 0,
      todayIphoneUserCount: 1,
      totalKeys: 320,
      transferedKeys: 305,
      balanceKeys: 15,
      totalIphoneKeys: 15,
      transferIphoneKeys: 10,
      balanceIphoneKeys: 5,
    },
  }
  const stats = roleStatsMap[role as UserRole] || DEFAULT_DASHBOARD_STATS

  return (
    <div className="space-y-6 pb-12 select-none">
      {/* 3-Column Grid of Metric Stadium Cards matching Screenshots */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Card 1: Analytics - Super Admin only */}
        {isSuper && (
          <div
            onClick={() => navigate(ROUTE_PATHS.ANALYTICS)}
            className="card-metric-stadium p-6 cursor-pointer group flex flex-col justify-between min-h-[140px]"
          >
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-50 border border-amber-200 shadow-xs group-hover:scale-105 transition-transform">
                <svg
                  viewBox="0 0 32 32"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-7 w-7"
                >
                  <path
                    d="M4 26H28"
                    stroke="#374151"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                  <path
                    d="M7 21L13 14L18 19L26 8"
                    stroke="#f59e0b"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle cx="21" cy="20" r="5" stroke="#3b82f6" strokeWidth="2" fill="#eff6ff" />
                  <path d="M25 24L28 27" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" />
                </svg>
              </div>
              <span className="text-xl font-bold text-gray-800">Analytics</span>
            </div>
            <div className="text-right text-xs font-bold text-blue-600 mt-2">
              View Analytics &rarr;
            </div>
          </div>
        )}

        {/* Card 2: Distributor - Super Admin / Stockist only */}
        {isStockist && (
          <div
            onClick={() => navigate(ROUTE_PATHS.DISTRIBUTORS)}
            className="card-metric-stadium p-6 cursor-pointer group flex flex-col justify-between min-h-[140px]"
          >
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#0d6efd] text-white shadow-sm group-hover:scale-105 transition-transform">
                <Users className="h-6 w-6" />
              </div>
              <span className="text-xl font-bold text-gray-800">Distributor</span>
            </div>
            <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
              {stats.distributorCount}
            </div>
          </div>
        )}

        {/* Card 3: Dealer - Super Admin / Stockist / Distributor */}
        {isDistributor && (
          <div
            onClick={() => navigate(ROUTE_PATHS.DEALERS)}
            className="card-metric-stadium p-6 cursor-pointer group flex flex-col justify-between min-h-[140px]"
          >
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#8b5cf6] text-white shadow-sm group-hover:scale-105 transition-transform">
                <Users className="h-6 w-6" />
              </div>
              <span className="text-xl font-bold text-gray-800">Dealer</span>
            </div>
            <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
              {stats.dealerCount}
            </div>
          </div>
        )}

        {/* Card 4: User */}
        <div
          onClick={() => navigate(ROUTE_PATHS.USERS)}
          className="card-metric-stadium p-6 cursor-pointer group flex flex-col justify-between min-h-[140px]"
        >
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 text-amber-800">
              <User className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-gray-800">User</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.userCount}
          </div>
        </div>

        {/* Card 5: Remove User */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 text-amber-800">
              <User className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-gray-800">Remove User</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.removeUserCount}
          </div>
        </div>

        {/* Card 6: Today's 3.0 User */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 text-amber-800">
              <User className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-gray-800">Today's 3.0 User</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.today30UserCount}
          </div>
        </div>

        {/* Card 7: Today's Running User */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 text-amber-800">
              <User className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-gray-800">Today's Running User</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.todayRunningUserCount}
          </div>
        </div>

        {/* Card 8: Today's iPhone User */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-100 text-amber-800">
              <User className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-gray-800">Today's iPhone User</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.todayIphoneUserCount}
          </div>
        </div>

        {/* Card 9: Total Keys */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-blue-100 text-blue-600">
              <Key className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-800">Total Keys</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.totalKeys}
          </div>
        </div>

        {/* Card 10: Transfered Keys */}
        <div
          onClick={() => navigate(ROUTE_PATHS.REPORT_TRANSFER)}
          className="card-metric-stadium p-6 cursor-pointer group flex flex-col justify-between min-h-[140px]"
        >
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-rose-100 text-rose-500">
              <Key className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-800">Transfered</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.transferedKeys}
          </div>
        </div>

        {/* Card 11: Balance Keys */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
              <Key className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-800">Balance</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.balanceKeys}
          </div>
        </div>

        {/* Card 12: Total iPhone Keys */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-blue-100 text-blue-600">
              <Key className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-800">Total iPhone Keys</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.totalIphoneKeys}
          </div>
        </div>

        {/* Card 13: Transfer iPhone Keys */}
        <div
          onClick={() => navigate(ROUTE_PATHS.REPORT_IPHONE_TRANSFER)}
          className="card-metric-stadium p-6 cursor-pointer group flex flex-col justify-between min-h-[140px]"
        >
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-rose-100 text-rose-500">
              <Key className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-800">Transfer iPhone Keys</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.transferIphoneKeys}
          </div>
        </div>

        {/* Card 14: Balance iPhone Keys */}
        <div className="card-metric-stadium p-6 flex flex-col justify-between min-h-[140px]">
          <div className="flex items-center gap-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
              <Key className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-800">Balance iPhone Keys</span>
          </div>
          <div className="text-center text-4xl font-normal text-gray-900 tracking-tight font-sans mt-3">
            {stats.balanceIphoneKeys}
          </div>
        </div>
      </div>
    </div>
  )
}
