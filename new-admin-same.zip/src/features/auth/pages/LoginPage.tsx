import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Eye, EyeOff, ShieldCheck, Sparkles, ArrowRight, Lock, User } from 'lucide-react'
import { useAppDispatch } from '@/app/store/hooks'
import { setCredentials } from '../slices/authSlice'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Card } from '@/components/ui/Card'
import { toast } from 'sonner'
import type { UserRole } from '@/types/user'

interface DemoAccount {
  role: UserRole
  name: string
  identifier: string
  label: string
  desc: string
}

const DEMO_ACCOUNTS: DemoAccount[] = [
  {
    role: 'super_admin',
    name: 'Rajesh Sharma',
    identifier: 'admin@vcredit.in',
    label: 'Super Admin',
    desc: 'Platform Owner · Full Access',
  },
  {
    role: 'stockist',
    name: 'Aman Verma',
    identifier: 'stockist.north@vcredit.in',
    label: 'Stockist (Regional)',
    desc: 'North Region Inventory',
  },
  {
    role: 'distributor',
    name: 'Vikram Mehta',
    identifier: 'delhi.dist@vcredit.in',
    label: 'Distributor (City)',
    desc: 'Delhi NCR Hub',
  },
  {
    role: 'dealer',
    name: 'Karan Patel',
    identifier: 'metro.telecom@vcredit.in',
    label: 'Dealer (Retail)',
    desc: 'Metro Mobiles Store',
  },
]

export default function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const dispatch = useAppDispatch()

  const [identifier, setIdentifier] = useState('admin@vcredit.in')
  const [password, setPassword] = useState('password123')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [activeDemoRole, setActiveDemoRole] = useState<UserRole>('super_admin')

  const from = location.state?.from?.pathname || '/app/overview'

  const handleSelectDemo = (acc: DemoAccount) => {
    setIdentifier(acc.identifier)
    setPassword('password123')
    setActiveDemoRole(acc.role)
    toast.info(`Selected ${acc.label} credentials`)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!identifier || !password) {
      toast.error('Please enter both your identifier and password.')
      return
    }

    setIsLoading(true)

    // Simulating authentication delay
    setTimeout(() => {
      setIsLoading(false)

      const demoUser = DEMO_ACCOUNTS.find((d) => d.role === activeDemoRole) || DEMO_ACCOUNTS[0]

      dispatch(
        setCredentials({
          token: `demo_jwt_token_${Date.now()}`,
          user: {
            id: `usr_${activeDemoRole}`,
            name: demoUser.name,
            email: identifier.includes('@') ? identifier : `${identifier}@vcredit.in`,
            phone: '+91 98765 43210',
            role: activeDemoRole,
            status: 'active',
            availableKeys: activeDemoRole === 'dealer' ? 14 : 1500,
            allocatedKeys: activeDemoRole === 'dealer' ? 86 : 14200,
            walletBalance: 250000,
            createdAt: '2026-01-15T10:00:00Z',
          },
        })
      )

      toast.success(`Welcome back, ${demoUser.name}!`)
      navigate(from, { replace: true })
    }, 700)
  }

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4 bg-background overflow-hidden selection:bg-primary/20">
      {/* Background Decorative Mesh & Gradients */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-md space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-primary via-indigo-600 to-violet-600 shadow-xl shadow-primary/25 mb-1">
            <span className="text-2xl font-black text-white font-display">V</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-display text-foreground">
            V-Credit Console
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground">
            Sign in to manage license keys, MDM devices & EMI finances
          </p>
        </div>

        {/* Login Card */}
        <Card className="p-6 sm:p-8 backdrop-blur-xl bg-card/85 border-border/80 shadow-2xl rounded-3xl space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Email / Mobile / Username
              </label>
              <Input
                type="text"
                placeholder="e.g. admin@vcredit.in or 9876543210"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                leftIcon={<User className="h-4 w-4" />}
                required
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Password
                </label>
                <a
                  href="#forgot"
                  onClick={(e) => {
                    e.preventDefault()
                    toast.info('Password recovery link sent to registered mobile.')
                  }}
                  className="text-xs text-primary hover:underline font-medium"
                >
                  Forgot?
                </a>
              </div>
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                leftIcon={<Lock className="h-4 w-4" />}
                rightIcon={
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="hover:text-foreground transition-colors"
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                }
                required
              />
            </div>

            <Button
              type="submit"
              variant="gradient"
              className="w-full h-11 text-sm font-semibold rounded-xl mt-2"
              isLoading={isLoading}
              loadingText="Authenticating..."
              rightIcon={<ArrowRight className="h-4 w-4" />}
            >
              Sign In to Console
            </Button>
          </form>

          {/* Demo Accounts Quick-Select Accordion */}
          <div className="pt-4 border-t border-border/60 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                <Sparkles className="h-3 w-3 text-amber-500" />
                Quick Demo Personas
              </span>
              <span className="text-[10px] text-muted-foreground">Click to prefill</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {DEMO_ACCOUNTS.map((acc) => {
                const isSelected = activeDemoRole === acc.role
                return (
                  <button
                    key={acc.role}
                    type="button"
                    onClick={() => handleSelectDemo(acc)}
                    className={`flex flex-col text-left p-2.5 rounded-xl border text-xs transition-all ${
                      isSelected
                        ? 'border-primary bg-primary/10 shadow-sm'
                        : 'border-border/60 bg-muted/30 hover:bg-muted/70'
                    }`}
                  >
                    <span className="font-bold text-foreground text-xs leading-tight">
                      {acc.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground truncate mt-0.5">
                      {acc.name}
                    </span>
                  </button>
                )
              })}
            </div>
          </div>
        </Card>

        {/* Security Trust Footnote */}
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="h-4 w-4 text-emerald-500" />
          <span>V-Credit 256-bit Encrypted Operations Session</span>
        </div>
      </div>
    </div>
  )
}
